"""Example plugin construct. Drop any .py file in plugins/ and it is auto-loaded at boot.

Copy this file as a template: one decorated function = one construct.
"""
from datetime import datetime
from zoneinfo import ZoneInfo

from ring.hands.registry import register_tool


@register_tool(tags=("utility",))
def current_time(timezone: str = "Asia/Kolkata") -> dict:
    """Get the current date and time in a given IANA timezone.

    Args:
        timezone: IANA timezone name, e.g. 'Asia/Kolkata' or 'UTC'.
    """
    now = datetime.now(ZoneInfo(timezone))
    return {"timezone": timezone, "iso": now.isoformat(timespec="seconds"), "weekday": now.strftime("%A")}
