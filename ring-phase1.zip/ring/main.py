"""Launcher:  python main.py [--hud plain] [--voice] [--check] [--once "query"]"""
from ring.cli import main

if __name__ == "__main__":
    main()
