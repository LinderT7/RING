"""Core state machine: Standby -> Listening -> Processing -> Executing Construct -> Speaking."""
from __future__ import annotations

from enum import Enum

from .events import EventBus


class State(str, Enum):
    STANDBY = "STANDBY"
    LISTENING = "LISTENING"
    PROCESSING = "PROCESSING"
    EXECUTING = "EXECUTING_CONSTRUCT"
    SPEAKING = "SPEAKING"


HUD_LABELS = {
    State.STANDBY: "STANDBY",
    State.LISTENING: "SCANNING",
    State.PROCESSING: "ANALYZING",
    State.EXECUTING: "COMPILING CONSTRUCT",
    State.SPEAKING: "TRANSMITTING",
}

ALLOWED: dict[State, set[State]] = {
    State.STANDBY: {State.LISTENING, State.PROCESSING, State.SPEAKING},   # SPEAKING = proactive alert
    State.LISTENING: {State.PROCESSING, State.STANDBY},
    State.PROCESSING: {State.EXECUTING, State.SPEAKING, State.STANDBY},
    State.EXECUTING: {State.PROCESSING, State.SPEAKING, State.STANDBY},
    State.SPEAKING: {State.STANDBY, State.LISTENING},
}


class InvalidTransition(RuntimeError):
    pass


class StateMachine:
    def __init__(self, bus: EventBus):
        self.bus = bus
        self.state = State.STANDBY

    def transition(self, new: State, reason: str = "") -> None:
        if new == self.state:
            return
        if new not in ALLOWED[self.state]:
            raise InvalidTransition(f"{self.state.value} -> {new.value} is not permitted")
        old, self.state = self.state, new
        self.bus.emit("state", HUD_LABELS[new], old=old.value, new=new.value, reason=reason)

    def reset(self, reason: str = "reset") -> None:
        """Force back to STANDBY (error recovery / end of turn)."""
        if self.state is State.STANDBY:
            return
        old, self.state = self.state, State.STANDBY
        self.bus.emit("state", HUD_LABELS[State.STANDBY], old=old.value, new=State.STANDBY.value, reason=reason)
