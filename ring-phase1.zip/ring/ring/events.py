"""Event bus: the single channel between the core and every HUD / logger.

Rule: emit() is called from the event-loop thread only (audio callbacks hop
over with loop.call_soon_threadsafe), so subscribers may touch UI state directly.
"""
from __future__ import annotations

import logging
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable

log = logging.getLogger("ring.events")


@dataclass
class Event:
    kind: str          # user | ring | construct | system | alert | error | state | confirm | quit
    message: str = ""
    data: dict[str, Any] = field(default_factory=dict)
    ts: float = field(default_factory=time.time)


class EventBus:
    def __init__(self, maxlen: int = 500):
        self.history: deque[Event] = deque(maxlen=maxlen)
        self._subs: list[Callable[[Event], None]] = []

    def subscribe(self, cb: Callable[[Event], None]) -> Callable[[], None]:
        self._subs.append(cb)
        return lambda: self._subs.remove(cb) if cb in self._subs else None

    def emit(self, kind: str, message: str = "", **data: Any) -> Event:
        ev = Event(kind=kind, message=message, data=data)
        self.history.append(ev)
        for cb in list(self._subs):
            try:
                cb(ev)
            except Exception:  # a broken HUD must never take the core down
                log.exception("event subscriber failed")
        return ev
