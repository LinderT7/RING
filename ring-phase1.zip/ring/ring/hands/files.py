"""File constructs — confined to the workspace sandbox (workspace.roots)."""
from __future__ import annotations

import fnmatch
import os
import time
from pathlib import Path
from typing import Optional

from .registry import ToolContext, register_tool

SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", ".idea", ".vscode"}


def sandbox_roots(ctx: ToolContext) -> list[Path]:
    roots = [p.expanduser().resolve() for p in ctx.config.paths("workspace.roots")]
    if not roots:
        raise PermissionError("no workspace roots configured")
    for r in roots:
        r.mkdir(parents=True, exist_ok=True)
    return roots


def resolve_safe(ctx: ToolContext, path: str) -> Path:
    """Resolve `path` (relative to the first root) and refuse anything outside every root."""
    roots = sandbox_roots(ctx)
    p = Path(path).expanduser()
    if not p.is_absolute():
        p = roots[0] / p
    p = p.resolve()  # collapses .. and symlinks before the containment check
    if not any(p == r or r in p.parents for r in roots):
        raise PermissionError(f"path outside workspace sandbox: {path}")
    return p


def _rel(ctx: ToolContext, p: Path) -> str:
    for r in sandbox_roots(ctx):
        if p == r or r in p.parents:
            return str(p.relative_to(r)) or "."
    return str(p)


@register_tool(tags=("files",))
def list_directory(ctx: ToolContext, path: str = ".", max_entries: int = 100) -> dict:
    """List files and folders in a workspace directory.

    Args:
        path: directory relative to the workspace root.
        max_entries: cap on entries returned.
    """
    d = resolve_safe(ctx, path)
    if not d.is_dir():
        raise NotADirectoryError(f"not a directory: {path}")
    entries = []
    for child in sorted(d.iterdir(), key=lambda c: (not c.is_dir(), c.name.lower())):
        entries.append({"name": child.name + ("/" if child.is_dir() else ""),
                        "size": child.stat().st_size if child.is_file() else None})
        if len(entries) >= max_entries:
            break
    return {"path": _rel(ctx, d), "count": len(entries), "entries": entries}


@register_tool(tags=("files",))
def read_file(ctx: ToolContext, path: str, max_chars: int = 0) -> dict:
    """Read a text file from the workspace.

    Args:
        path: file relative to the workspace root.
        max_chars: maximum characters to return (0 = configured default).
    """
    f = resolve_safe(ctx, path)
    if not f.is_file():
        raise FileNotFoundError(f"no such file: {path}")
    limit = max_chars or int(ctx.config.get("workspace.max_read_chars", 8000))
    with f.open("rb") as fh:
        raw = fh.read(limit * 4 + 1)
    if b"\0" in raw[:4096]:
        return {"path": _rel(ctx, f), "binary": True, "size": f.stat().st_size}
    text = raw.decode("utf-8", errors="replace")
    return {"path": _rel(ctx, f), "truncated": len(text) > limit or f.stat().st_size > len(raw),
            "content": text[:limit]}


def _confirm_write(args: dict, ctx: ToolContext) -> bool:
    try:
        return resolve_safe(ctx, args["path"]).exists()  # overwriting/appending needs authorization
    except Exception:
        return True


@register_tool(confirm=_confirm_write, tags=("files",))
def write_file(ctx: ToolContext, path: str, content: str, append: bool = False) -> dict:
    """Write a text file in the workspace (creates parent folders). Existing files need Operator authorization.

    Args:
        path: file relative to the workspace root.
        content: full text to write.
        append: append instead of overwriting.
    """
    f = resolve_safe(ctx, path)
    f.parent.mkdir(parents=True, exist_ok=True)
    with f.open("a" if append else "w", encoding="utf-8") as fh:
        fh.write(content)
    return {"path": _rel(ctx, f), "bytes_written": len(content.encode("utf-8")), "mode": "append" if append else "write"}


@register_tool(tags=("files",))
def search_files(ctx: ToolContext, pattern: str = "*", query: Optional[str] = None, path: str = ".", max_results: int = 25) -> dict:
    """Find files by name pattern, optionally grepping their text for a phrase.

    Args:
        pattern: filename glob, e.g. '*.py' or 'notes*'.
        query: case-insensitive text to look for inside matching files.
        path: directory to search, relative to the workspace root.
        max_results: cap on results.
    """
    base = resolve_safe(ctx, path)
    deadline = time.monotonic() + 5
    results: list[dict] = []
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            if time.monotonic() > deadline or len(results) >= max_results:
                return {"results": results, "truncated": True}
            if not fnmatch.fnmatch(name.lower(), pattern.lower()):
                continue
            fp = Path(dirpath) / name
            if not query:
                results.append({"path": _rel(ctx, fp)})
                continue
            try:
                if fp.stat().st_size > 1_000_000:
                    continue
                for n, line in enumerate(fp.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                    if query.lower() in line.lower():
                        results.append({"path": _rel(ctx, fp), "line": n, "text": line.strip()[:160]})
                        if len(results) >= max_results:
                            break
            except OSError:
                continue
    return {"results": results, "truncated": False}
