"""Hardware hooks (Serial / MQTT) — placeholders wired to config, off by default.

Both constructs are functional if `hardware.enabled: true` and the optional
library is installed (pyserial / paho-mqtt), and both always require authorization.
"""
from __future__ import annotations

import os

from .registry import ToolContext, register_tool


def _require_enabled(ctx: ToolContext) -> None:
    if not ctx.config.get("hardware.enabled", False):
        raise PermissionError("hardware link disabled — set hardware.enabled: true in config.yaml")


@register_tool(confirm=True, tags=("hardware",))
def serial_send(ctx: ToolContext, data: str, expect_reply: bool = True, port: str = "", baud: int = 0) -> dict:
    """Send one line to the configured serial device (ESP32/Arduino/etc.) and optionally read one reply line.

    Args:
        data: text to transmit (a newline is appended).
        expect_reply: wait for one reply line.
        port: serial port override (defaults to hardware.serial.port).
        baud: baud-rate override (defaults to hardware.serial.baud).
    """
    _require_enabled(ctx)
    cfg = ctx.config
    port = port or cfg.get("hardware.serial.port", "")
    if not port:
        raise ValueError("no serial port configured (SERIAL_PORT in .env or hardware.serial.port)")
    try:
        import serial  # pyserial
    except ImportError as exc:
        raise RuntimeError("pyserial not installed: pip install pyserial") from exc
    timeout = float(cfg.get("hardware.serial.timeout_s", 2))
    with serial.Serial(port, baud or int(cfg.get("hardware.serial.baud", 115200)), timeout=timeout) as ser:
        ser.write((data + "\n").encode())
        reply = ser.readline().decode(errors="replace").strip() if expect_reply else None
    return {"port": port, "sent": data, "reply": reply}


@register_tool(confirm=True, tags=("hardware",))
def mqtt_publish(ctx: ToolContext, topic: str, payload: str, retain: bool = False) -> dict:
    """Publish an MQTT message. The topic is forced under the configured base topic.

    Args:
        topic: topic suffix, e.g. 'hand/grip'.
        payload: message body.
        retain: set the MQTT retain flag.
    """
    _require_enabled(ctx)
    cfg = ctx.config
    host = cfg.get("hardware.mqtt.host", "")
    if not host:
        raise ValueError("no MQTT host configured (MQTT_HOST in .env or hardware.mqtt.host)")
    try:
        import paho.mqtt.publish as publish
    except ImportError as exc:
        raise RuntimeError("paho-mqtt not installed: pip install paho-mqtt") from exc
    base = cfg.get("hardware.mqtt.base_topic", "ring/")
    full = topic if topic.startswith(base) else base + topic.lstrip("/")
    user = cfg.get("hardware.mqtt.username", "")
    auth = {"username": user, "password": os.environ.get(cfg.get("hardware.mqtt.password_env", "MQTT_PASSWORD"), "")} if user else None
    publish.single(full, payload, hostname=host, port=int(cfg.get("hardware.mqtt.port", 1883)), auth=auth, retain=retain)
    return {"topic": full, "payload": payload}
