"""Construct engine: the @register_tool registry.

A tool is a plain Python function. The decorator builds its JSON schema from
type hints + a Google-style docstring, so adding a construct is one function:

    @register_tool
    def my_tool(ctx: ToolContext, target: str, count: int = 3) -> dict:
        '''One-line description the model sees.

        Args:
            target: what to act on.
            count: how many times.
        '''

A parameter named `ctx` is injected at call time and hidden from the schema.
"""
from __future__ import annotations

import asyncio
import importlib
import importlib.util
import inspect
import json
import logging
import re
import types
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Literal, Union, get_args, get_origin, get_type_hints

from ..config import Config

log = logging.getLogger("ring.hands")

BUILTIN_MODULES = ("telemetry", "files", "shell", "hardware")


@dataclass
class ToolContext:
    config: Config
    ring: Any = None  # the orchestrator, for tools that need core state


class ToolArgumentError(ValueError):
    pass


ConfirmSpec = Union[bool, Callable[[dict, ToolContext], bool]]

_PRIMS = {str: "string", int: "integer", float: "number", bool: "boolean"}


def _json_type(tp: Any) -> dict:
    origin = get_origin(tp)
    if tp in _PRIMS:
        return {"type": _PRIMS[tp]}
    if origin is Literal:
        return {"type": "string", "enum": list(get_args(tp))}
    if origin in (list, set, tuple) or tp in (list, set, tuple):
        args = get_args(tp)
        return {"type": "array", "items": _json_type(args[0]) if args else {}}
    if origin is dict or tp is dict:
        return {"type": "object"}
    if origin is Union or origin is getattr(types, "UnionType", None):
        non_none = [a for a in get_args(tp) if a is not type(None)]
        return _json_type(non_none[0]) if len(non_none) == 1 else {}
    return {"type": "string"}


def _is_optional(tp: Any) -> bool:
    origin = get_origin(tp)
    return (origin is Union or origin is getattr(types, "UnionType", None)) and type(None) in get_args(tp)


def _parse_doc(doc: str | None) -> tuple[str, dict[str, str]]:
    doc = inspect.cleandoc(doc or "")
    head, _, rest = doc.partition("\nArgs:")
    params: dict[str, str] = {}
    current = None
    for line in rest.splitlines():
        m = re.match(r"\s+(\w+)\s*(?:\([^)]*\))?:\s*(.*)", line)
        if m:
            current = m.group(1)
            params[current] = m.group(2).strip()
        elif line.strip() and line.startswith(" ") and current:
            params[current] += " " + line.strip()
        elif line.strip():
            break  # next section (Returns:, etc.)
    return " ".join(head.split()), params


def _coerce(value: Any, spec: dict) -> Any:
    t = spec.get("type")
    try:
        if t == "integer" and not isinstance(value, bool):
            value = int(float(value))
        elif t == "number" and not isinstance(value, bool):
            value = float(value)
        elif t == "boolean" and isinstance(value, str):
            value = value.strip().lower() in {"1", "true", "yes", "y"}
        elif t == "array" and isinstance(value, str):
            value = json.loads(value)
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        raise ToolArgumentError(f"cannot read {value!r} as {t}") from exc
    if "enum" in spec and value not in spec["enum"]:
        raise ToolArgumentError(f"{value!r} not in {spec['enum']}")
    return value


@dataclass
class Tool:
    name: str
    description: str
    func: Callable
    parameters: dict
    confirm: ConfirmSpec = False
    tags: tuple[str, ...] = ()
    takes_ctx: bool = False
    is_async: bool = False

    @classmethod
    def from_function(cls, func: Callable, *, name=None, description=None, confirm: ConfirmSpec = False, tags=()) -> "Tool":
        sig = inspect.signature(func)
        try:
            hints = get_type_hints(func)
        except Exception:
            # One unresolvable annotation must not erase the rest: resolve parameter by parameter.
            # (Annotation strings come from the tool author's own source, same trust as get_type_hints.)
            hints = {}
            for n, p in sig.parameters.items():
                ann = p.annotation
                if ann is inspect.Parameter.empty:
                    continue
                if isinstance(ann, str):
                    try:
                        ann = eval(ann, getattr(func, "__globals__", {}), {})  # noqa: S307
                    except Exception:
                        continue
                hints[n] = ann
        doc_desc, doc_params = _parse_doc(func.__doc__)
        props: dict[str, dict] = {}
        required: list[str] = []
        takes_ctx = False
        for pname, p in sig.parameters.items():
            if pname == "ctx":
                takes_ctx = True
                continue
            tp = hints.get(pname, str)
            spec = _json_type(tp)
            if pname in doc_params:
                spec["description"] = doc_params[pname]
            if p.default is not inspect.Parameter.empty:
                if isinstance(p.default, (str, int, float, bool)):
                    spec["default"] = p.default
            elif not _is_optional(tp):
                required.append(pname)
            props[pname] = spec
        return cls(
            name=name or func.__name__,
            description=description or doc_desc or func.__name__,
            func=func,
            parameters={"type": "object", "properties": props, "required": required},
            confirm=confirm,
            tags=tuple(tags),
            takes_ctx=takes_ctx,
            is_async=inspect.iscoroutinefunction(func),
        )

    def schema(self) -> dict:
        return {
            "type": "function",
            "function": {"name": self.name, "description": self.description, "parameters": self.parameters},
        }

    def bind(self, raw: dict) -> dict:
        props = self.parameters["properties"]
        out = {k: _coerce(v, props[k]) for k, v in (raw or {}).items() if k in props and v is not None}
        missing = [r for r in self.parameters["required"] if r not in out]
        if missing:
            raise ToolArgumentError(f"missing required argument(s): {', '.join(missing)}")
        return out


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}
        self.load_errors: list[str] = []

    def __len__(self) -> int:
        return len(self._tools)

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def names(self) -> list[str]:
        return sorted(self._tools)

    def tools(self) -> list[Tool]:
        return [self._tools[n] for n in self.names()]

    def schemas(self) -> list[dict]:
        return [t.schema() for t in self.tools()]

    def needs_confirmation(self, name: str, arguments: dict, ctx: ToolContext) -> bool:
        tool = self._tools[name]
        args = tool.bind(arguments)  # invalid calls fail here, before any prompt
        if callable(tool.confirm):
            return bool(tool.confirm(args, ctx))
        return bool(tool.confirm)

    async def invoke(self, name: str, arguments: dict, ctx: ToolContext) -> Any:
        tool = self._tools[name]
        args = tool.bind(arguments)
        if tool.takes_ctx:
            args["ctx"] = ctx
        if tool.is_async:
            return await tool.func(**args)
        return await asyncio.to_thread(tool.func, **args)

    # ------------------------------------------------------------ discovery
    def load_builtin(self) -> None:
        for mod in BUILTIN_MODULES:
            importlib.import_module(f".{mod}", __package__)

    def load_plugins(self, directory: Path) -> list[str]:
        """Import every *.py in `directory`; their @register_tool calls self-register."""
        loaded: list[str] = []
        if not directory.is_dir():
            return loaded
        for path in sorted(directory.glob("*.py")):
            if path.name.startswith("_"):
                continue
            try:
                spec = importlib.util.spec_from_file_location(f"ring_plugin_{path.stem}", path)
                module = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
                spec.loader.exec_module(module)  # type: ignore[union-attr]
                loaded.append(path.stem)
            except Exception as exc:
                msg = f"plugin {path.name} failed: {type(exc).__name__}: {exc}"
                log.exception(msg)
                self.load_errors.append(msg)
        return loaded


default_registry = ToolRegistry()


def register_tool(func=None, *, name=None, description=None, confirm: ConfirmSpec = False, tags=(), registry: ToolRegistry | None = None):
    """Register a function as a construct. Usable bare or with arguments.

    confirm: True to always require Operator authorization, or a callable
             (args, ctx) -> bool deciding per call.
    """

    def wrap(f: Callable) -> Callable:
        (registry if registry is not None else default_registry).register(
            Tool.from_function(f, name=name, description=description, confirm=confirm, tags=tags)
        )
        return f

    return wrap(func) if func is not None else wrap
