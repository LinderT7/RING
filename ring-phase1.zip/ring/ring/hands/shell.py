"""Shell constructs.

Safety model (be clear-eyed): the deny-list and auto-allow list are speed bumps,
NOT a security boundary. The real gate is Operator authorization — any command
outside the strict auto-allow set requires an explicit 'yes' from the Operator.
"""
from __future__ import annotations

import asyncio
import os
import re
import shlex
import sys

from ..config import Config
from .files import resolve_safe
from .registry import ToolContext, register_tool

DENY_PATTERNS = [
    (r"\brm\s+(-[a-z]+\s+)*(/|~|\*|/\*)(\s|$)", "recursive delete of root/home/wildcard"),
    (r"\bmkfs(\.\w+)?\b", "filesystem format"),
    (r"\bdd\b.*\bof=/dev/", "raw device write"),
    (r">\s*/dev/(sd|nvme|hd)", "raw device write"),
    (r":\(\)\s*\{\s*:\|:&\s*\};:", "fork bomb"),
    (r"\b(shutdown|reboot|halt|poweroff)\b", "power control"),
    (r"\bformat\s+[a-z]:", "drive format"),
    (r"\bdel\s+/[sfq]", "recursive delete"),
    (r"\brmdir\s+/s", "recursive delete"),
    (r"\b(curl|wget|iwr|Invoke-WebRequest)\b.*\|\s*(sh|bash|zsh|iex|powershell|pwsh)", "pipe-to-shell"),
    (r"\bchmod\s+-R\s+777\s+/", "global permission change"),
    (r"\bsudo\b|\brunas\b", "privilege escalation"),
]
SHELL_META = set(";&|<>`$\n")


def denied_reason(command: str) -> str | None:
    for pattern, reason in DENY_PATTERNS:
        if re.search(pattern, command, re.IGNORECASE):
            return reason
    return None


def is_auto_allowed(command: str, cfg: Config) -> bool:
    if any(ch in SHELL_META for ch in command):
        return False
    try:
        tokens = shlex.split(command, posix=(os.name != "nt"))
    except ValueError:
        return False
    if not tokens:
        return False
    # Arguments that point outside the workspace (absolute, home, parent, drive paths) need authorization.
    for t in tokens[1:]:
        if t.startswith(("/", "~", "\\")) or ".." in t or re.match(r"^[A-Za-z]:", t):
            return False
    allow = {a.lower() for a in cfg.get("shell.auto_allow", [])}
    prefixes = [p.lower() for p in cfg.get("shell.auto_allow_prefixes", [])]
    head = os.path.basename(tokens[0]).lower().removesuffix(".exe")
    two = " ".join(tokens[:2]).lower()
    return head in allow and head != "git" or any(two == p or command.lower().strip() == p for p in prefixes)


async def _run(proc: asyncio.subprocess.Process, timeout: float, max_chars: int) -> dict:
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        return {"exit_code": None, "timed_out": True, "output": ""}
    text = out.decode("utf-8", errors="replace")
    return {"exit_code": proc.returncode, "output": text[:max_chars], "truncated": len(text) > max_chars}


@register_tool(confirm=lambda args, ctx: not is_auto_allowed(args.get("command", ""), ctx.config), tags=("shell",))
async def run_command(ctx: ToolContext, command: str, cwd: str = ".", timeout_s: int = 0) -> dict:
    """Run a shell command inside the workspace sandbox and return its output. Read-only basics run immediately; anything else needs Operator authorization.

    Args:
        command: the command line to execute.
        cwd: working directory relative to the workspace root.
        timeout_s: seconds before the command is killed (0 = configured default).
    """
    cfg = ctx.config
    if not cfg.get("shell.enabled", True):
        raise PermissionError("shell constructs are disabled in config")
    if reason := denied_reason(command):
        raise PermissionError(f"blocked by safety policy ({reason})")
    work = resolve_safe(ctx, cwd)
    proc = await asyncio.create_subprocess_shell(
        command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, cwd=str(work)
    )
    return await _run(proc, timeout_s or float(cfg.get("shell.timeout_s", 30)), int(cfg.get("shell.max_output_chars", 4000)))


@register_tool(confirm=True, tags=("shell",))
async def run_script(ctx: ToolContext, path: str, args: str = "", timeout_s: int = 0) -> dict:
    """Execute a Python script from the workspace. Always requires Operator authorization.

    Args:
        path: script file relative to the workspace root.
        args: space-separated command-line arguments.
        timeout_s: seconds before the script is killed (0 = configured default).
    """
    cfg = ctx.config
    if not cfg.get("shell.enabled", True):
        raise PermissionError("shell constructs are disabled in config")
    script = resolve_safe(ctx, path)
    if script.suffix != ".py" or not script.is_file():
        raise FileNotFoundError(f"not a Python script: {path}")
    proc = await asyncio.create_subprocess_exec(
        sys.executable, str(script), *shlex.split(args),
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, cwd=str(script.parent),
    )
    return await _run(proc, timeout_s or float(cfg.get("shell.timeout_s", 30)), int(cfg.get("shell.max_output_chars", 4000)))
