"""System telemetry = Ring Charge. Used by the HUD, the alert monitor and the scan constructs."""
from __future__ import annotations

import logging
import shutil
import subprocess
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Literal, Optional

import psutil

from .registry import ToolContext, register_tool

log = logging.getLogger("ring.telemetry")


@dataclass
class Snapshot:
    ts: float
    cpu_percent: float
    cpu_count: int
    ram_percent: float
    ram_used_gb: float
    ram_total_gb: float
    disk_percent: float
    disk_free_gb: float
    battery_percent: Optional[float]
    plugged: Optional[bool]
    battery_secs_left: Optional[int]
    gpus: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    def charge_text(self) -> str:
        if self.battery_percent is None:
            return "Ring Charge on mains power, no battery detected"
        mode = "charging" if self.plugged else "discharging"
        return f"Ring Charge {self.battery_percent:.0f} percent, {mode}"

    def readout(self, charge_alert_pct: float = 20, ram_alert_pct: float = 92) -> str:
        parts = [f"CPU {self.cpu_percent:.0f} percent", f"RAM {self.ram_percent:.0f} percent"]
        for g in self.gpus[:2]:
            temp = f", {g['temp_c']} C" if g.get("temp_c") is not None else ""
            parts.append(f"GPU {g['name']} at {g['util_percent']} percent{temp}")
        if not self.gpus:
            parts.append("no GPU telemetry")
        parts.append(f"disk {self.disk_percent:.0f} percent used")
        parts.append(self.charge_text())
        flags = []
        if self.battery_percent is not None and self.plugged is not True and self.battery_percent < charge_alert_pct:
            flags.append("Ring Charge low")
        if self.ram_percent >= ram_alert_pct:
            flags.append("memory pressure")
        if any((g.get("temp_c") or 0) >= 85 for g in self.gpus):
            flags.append("GPU thermal warning")
        verdict = f"Attention: {', '.join(flags)}." if flags else "All systems nominal."
        return "Scanning local telemetry. " + ". ".join(parts) + ". " + verdict


class Telemetry:
    def __init__(self) -> None:
        psutil.cpu_percent(None)  # prime the non-blocking counter
        self._gpu_backend: str | None = None
        self._nvml = None
        self._disk_anchor = Path.home().anchor or "/"

    def snapshot(self) -> Snapshot:
        vm = psutil.virtual_memory()
        try:
            du = psutil.disk_usage(self._disk_anchor)
            disk_pct, disk_free = du.percent, du.free / 2**30
        except OSError:
            disk_pct, disk_free = 0.0, 0.0
        batt = psutil.sensors_battery() if hasattr(psutil, "sensors_battery") else None
        secs = None
        if batt and isinstance(batt.secsleft, int) and batt.secsleft > 0:
            secs = batt.secsleft
        return Snapshot(
            ts=time.time(),
            cpu_percent=psutil.cpu_percent(None),
            cpu_count=psutil.cpu_count() or 0,
            ram_percent=vm.percent,
            ram_used_gb=vm.used / 2**30,
            ram_total_gb=vm.total / 2**30,
            disk_percent=disk_pct,
            disk_free_gb=disk_free,
            battery_percent=float(batt.percent) if batt else None,
            plugged=batt.power_plugged if batt else None,
            battery_secs_left=secs,
            gpus=self._gpus(),
        )

    # ---------------------------------------------------------------- GPU
    def _detect_gpu(self) -> str:
        try:
            import pynvml

            pynvml.nvmlInit()
            self._nvml = pynvml
            return "nvml"
        except Exception:
            pass
        return "smi" if shutil.which("nvidia-smi") else "none"

    def _gpus(self) -> list[dict]:
        if self._gpu_backend is None:
            self._gpu_backend = self._detect_gpu()
        try:
            if self._gpu_backend == "nvml":
                return self._gpus_nvml()
            if self._gpu_backend == "smi":
                return self._gpus_smi()
        except Exception as exc:
            log.warning("GPU telemetry failed (%s); disabling", exc)
            self._gpu_backend = "none"
        return []

    def _gpus_nvml(self) -> list[dict]:
        nv = self._nvml
        out = []
        for i in range(nv.nvmlDeviceGetCount()):
            h = nv.nvmlDeviceGetHandleByIndex(i)
            name = nv.nvmlDeviceGetName(h)
            mem = nv.nvmlDeviceGetMemoryInfo(h)
            out.append(
                {
                    "name": name.decode() if isinstance(name, bytes) else str(name),
                    "util_percent": nv.nvmlDeviceGetUtilizationRates(h).gpu,
                    "mem_used_mb": mem.used // 2**20,
                    "mem_total_mb": mem.total // 2**20,
                    "temp_c": nv.nvmlDeviceGetTemperature(h, nv.NVML_TEMPERATURE_GPU),
                }
            )
        return out

    def _gpus_smi(self) -> list[dict]:
        res = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3,
        )
        out = []
        for line in res.stdout.strip().splitlines():
            name, util, used, total, temp = [x.strip() for x in line.split(",")]
            out.append({"name": name, "util_percent": int(util), "mem_used_mb": int(used),
                        "mem_total_mb": int(total), "temp_c": int(temp)})
        return out


telemetry = Telemetry()


# ------------------------------------------------------------------ constructs
@register_tool(tags=("telemetry",))
def scan_telemetry(detail: Literal["summary", "full"] = "summary") -> dict:
    """Scan live system telemetry: CPU, RAM, disk, GPU and Ring Charge (battery).

    Args:
        detail: 'summary' for headline figures, 'full' to add per-core load and the heaviest processes.
    """
    snap = telemetry.snapshot().to_dict()
    if detail == "full":
        snap["per_core_percent"] = psutil.cpu_percent(interval=0.3, percpu=True)
        snap["top_processes"] = _top_processes("cpu", 5)
    return snap


@register_tool(tags=("telemetry",))
def ring_charge() -> dict:
    """Report Ring Charge: battery percentage, charging state and estimated time remaining."""
    s = telemetry.snapshot()
    return {
        "battery_percent": s.battery_percent,
        "plugged_in": s.plugged,
        "minutes_remaining": round(s.battery_secs_left / 60) if s.battery_secs_left else None,
        "status": s.charge_text(),
    }


def _top_processes(sort_by: str, limit: int) -> list[dict]:
    procs = list(psutil.process_iter(["pid", "name"]))
    for p in procs:
        try:
            p.cpu_percent(None)
        except psutil.Error:
            pass
    time.sleep(0.3)
    rows = []
    for p in procs:
        try:
            rows.append({"pid": p.pid, "name": p.info["name"], "cpu_percent": p.cpu_percent(None),
                         "mem_percent": round(p.memory_percent(), 1)})
        except psutil.Error:
            continue
    key = "mem_percent" if sort_by == "memory" else "cpu_percent"
    return sorted(rows, key=lambda r: r[key], reverse=True)[:limit]


@register_tool(tags=("telemetry",))
def top_processes(sort_by: Literal["cpu", "memory"] = "cpu", limit: int = 5) -> list:
    """List the heaviest running processes.

    Args:
        sort_by: rank by 'cpu' or 'memory'.
        limit: number of processes to return (1-20).
    """
    return _top_processes(sort_by, max(1, min(limit, 20)))


@register_tool(tags=("telemetry",))
def api_usage(ctx: ToolContext) -> dict:
    """Report neural-gateway (LLM) usage this session: calls, tokens, cost, active backend."""
    if ctx.ring is None:
        return {"error": "core not attached"}
    return asdict(ctx.ring.router.usage) | {"mode": ctx.ring.router.describe()}
