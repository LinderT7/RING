"""Audio output helpers + the sci-fi chime (synthesised, no asset files)."""
from __future__ import annotations

import asyncio


def synth_chime(kind: str = "speak", sr: int = 24000):
    """A subtle two-tone rising chime (wake/speak) or a lower triple pulse (alert)."""
    import numpy as np

    notes = {"wake": [(660, 0.10), (990, 0.22)], "speak": [(880, 0.09), (1320, 0.20)],
             "alert": [(520, 0.12), (520, 0.12), (390, 0.24)]}.get(kind, [(880, 0.2)])
    chunks = []
    for freq, dur in notes:
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        env = np.exp(-t * 11) * (1 - np.exp(-t * 400))                     # fast attack, glassy decay
        wave = np.sin(2 * np.pi * freq * t) + 0.3 * np.sin(2 * np.pi * freq * 2 * t)
        wave += 0.08 * np.sin(2 * np.pi * (freq * 1.5 + 6 * np.sin(2 * np.pi * 5 * t)) * t)  # faint shimmer
        chunks.append(wave * env)
    audio = np.concatenate(chunks)
    return (0.22 * audio / max(1e-9, np.max(np.abs(audio)))).astype("float32"), sr


class AudioOut:
    """Blocking sounddevice playback pushed to a worker thread so the loop stays live."""

    def __init__(self) -> None:
        self._sd = None

    def _get(self):
        if self._sd is None:
            import sounddevice as sd

            self._sd = sd
        return self._sd

    async def play(self, samples, sr: int) -> None:
        sd = self._get()

        def _run() -> None:
            sd.play(samples, sr)
            sd.wait()

        await asyncio.to_thread(_run)

    def stop(self) -> None:
        try:
            self._get().stop()
        except Exception:
            pass
