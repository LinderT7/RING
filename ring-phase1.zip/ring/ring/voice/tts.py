"""Voice: local TTS (piper / kokoro) with a chime before speaking.

NullTTS is used when voice is off or a backend fails to load — RING then
degrades to text readouts instead of crashing.
"""
from __future__ import annotations

import asyncio
import io
import logging
import re
import wave
from pathlib import Path

from ..config import Config
from ..events import EventBus

log = logging.getLogger("ring.tts")


def clean_for_speech(text: str) -> str:
    text = re.sub(r"```.*?```", " code omitted. ", text, flags=re.S)
    text = re.sub(r"https?://\S+", "link", text)
    text = re.sub(r"[`*_#>|]+", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+", text)
    return [p for p in (s.strip() for s in parts) if p]


class NullTTS:
    enabled = False
    muted = False

    async def load(self) -> None: ...
    async def speak(self, text: str) -> None: ...
    async def chime(self, kind: str = "speak") -> None: ...
    def stop(self) -> None: ...


class BaseTTS(NullTTS):
    backend = "base"

    def __init__(self, cfg: Config, bus: EventBus):
        from .audio import AudioOut

        self.cfg, self.bus = cfg, bus
        self.audio = AudioOut()
        self.chime_enabled = bool(cfg.get("tts.chime", True))
        self.enabled = False
        self.muted = False
        self._stop = False

    # subclasses implement
    def _load(self) -> None: raise NotImplementedError
    def _synth(self, text: str): raise NotImplementedError  # -> (samples, sample_rate)

    async def load(self) -> None:
        try:
            await asyncio.to_thread(self._load)
            self.enabled = True
            self.bus.emit("system", f"Voice online: {self.backend}.")
        except Exception as exc:
            self.enabled = False
            self.bus.emit("error", f"Voice offline ({self.backend}): {exc}. Text readouts only.")
            log.exception("TTS load failed")

    async def chime(self, kind: str = "speak") -> None:
        if not (self.enabled and self.chime_enabled) or self.muted:
            return
        try:
            from .audio import synth_chime

            await self.audio.play(*synth_chime(kind))
        except Exception:
            log.exception("chime failed")

    async def speak(self, text: str) -> None:
        if not self.enabled or self.muted:
            return
        sentences = split_sentences(clean_for_speech(text))
        if not sentences:
            return
        self._stop = False
        await self.chime("speak")
        nxt = asyncio.create_task(asyncio.to_thread(self._synth, sentences[0]))
        try:
            for i in range(len(sentences)):
                samples, sr = await nxt
                if i + 1 < len(sentences):  # synthesise the next sentence while this one plays
                    nxt = asyncio.create_task(asyncio.to_thread(self._synth, sentences[i + 1]))
                if self._stop:
                    break
                await self.audio.play(samples, sr)
        except Exception as exc:
            self.bus.emit("error", f"Voice fault: {exc}")
            log.exception("speak failed")
        finally:
            if not nxt.done():
                nxt.cancel()

    def stop(self) -> None:
        self._stop = True
        self.audio.stop()


class PiperTTS(BaseTTS):
    backend = "piper"

    def _load(self) -> None:
        from piper import PiperVoice

        model = self.cfg.path("tts.piper.model_path")
        if not model.exists():
            raise FileNotFoundError(f"Piper voice not found at {model} (see README, Voice setup)")
        self._voice = PiperVoice.load(str(model))

    def _synth(self, text: str):
        import numpy as np

        v = self._voice
        if hasattr(v, "synthesize_stream_raw"):                      # piper-tts 1.2.x
            raw = b"".join(v.synthesize_stream_raw(text))
            return np.frombuffer(raw, dtype=np.int16), v.config.sample_rate
        try:                                                          # piper-tts 1.3+: yields AudioChunk
            chunks = list(v.synthesize(text))
            if chunks and hasattr(chunks[0], "audio_int16_bytes"):
                audio = np.concatenate([np.frombuffer(c.audio_int16_bytes, dtype=np.int16) for c in chunks])
                return audio, chunks[0].sample_rate
        except TypeError:
            pass
        buf = io.BytesIO()                                            # last resort: WAV round-trip
        with wave.open(buf, "wb") as wf:
            v.synthesize(text, wf)
        buf.seek(0)
        with wave.open(buf, "rb") as wf:
            return np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16), wf.getframerate()


class KokoroTTS(BaseTTS):
    backend = "kokoro"

    def _load(self) -> None:
        from kokoro_onnx import Kokoro

        model, voices = self.cfg.path("tts.kokoro.model_path"), self.cfg.path("tts.kokoro.voices_path")
        for p in (model, voices):
            if not Path(p).exists():
                raise FileNotFoundError(f"Kokoro file not found: {p} (see README, Voice setup)")
        self._k = Kokoro(str(model), str(voices))

    def _synth(self, text: str):
        samples, sr = self._k.create(
            text, voice=self.cfg.get("tts.kokoro.voice", "am_michael"),
            speed=float(self.cfg.get("tts.kokoro.speed", 1.05)), lang="en-us",
        )
        return samples, sr


def create_tts(cfg: Config, bus: EventBus):
    if not cfg.get("tts.enabled", False):
        return NullTTS()
    backend = str(cfg.get("tts.backend", "piper")).lower()
    if backend == "piper":
        return PiperTTS(cfg, bus)
    if backend == "kokoro":
        return KokoroTTS(cfg, bus)
    return NullTTS()
