"""`python main.py --check` — preflight scan of the whole RING stack."""
from __future__ import annotations

import importlib
import json
import os
import sys
import urllib.request

from rich.console import Console
from rich.table import Table

from .config import Config

OK, WARN, FAIL = "[green]ONLINE[/]", "[yellow]OPTIONAL[/]", "[red]MISSING[/]"


def _has(module: str) -> bool:
    try:
        importlib.import_module(module)
        return True
    except Exception:
        return False


def _ollama(cfg: Config) -> tuple[str, str]:
    base = cfg.get("llm.local.api_base", "http://localhost:11434").rstrip("/")
    want = str(cfg.get("llm.local.model", "")).split("/", 1)[-1]
    try:
        with urllib.request.urlopen(base + "/api/tags", timeout=1.5) as r:
            names = [m["name"] for m in json.load(r).get("models", [])]
    except Exception as exc:
        return FAIL, f"{base} unreachable ({type(exc).__name__}). Start Ollama: `ollama serve`"
    if want in names or any(n.startswith(want.split(":")[0]) and ":" not in want for n in names):
        return OK, f"{base} · model {want} present"
    return WARN, f"{base} up, but model '{want}' not pulled. Run: ollama pull {want}"


def run_preflight(cfg: Config, console: Console | None = None) -> None:
    console = console or Console()
    t = Table(title="RING // Preflight Scan", header_style="bold green")
    for col in ("Subsystem", "Status", "Detail"):
        t.add_column(col)

    t.add_row("Python", OK if sys.version_info >= (3, 10) else FAIL, sys.version.split()[0] + " (need 3.10+)")
    for mod, label in [("rich", "rich"), ("textual", "textual (full HUD)"), ("psutil", "psutil"), ("yaml", "PyYAML"),
                       ("dotenv", "python-dotenv"), ("litellm", "litellm (gateway)"), ("pynvml", "pynvml (NVIDIA GPU stats)")]:
        t.add_row(label, OK if _has(mod) else (WARN if mod == "pynvml" else FAIL), "")

    status, detail = _ollama(cfg)
    t.add_row("Local brain (Ollama)", status, detail)
    key_env = cfg.get("llm.cloud.api_key_env", "OPENROUTER_API_KEY")
    t.add_row("Cloud brain (OpenRouter)", OK if os.environ.get(key_env) else WARN, f"{key_env} {'set' if os.environ.get(key_env) else 'not set'}")
    t.add_row("Gateway mode", OK, str(cfg.get("llm.mode")))
    ws = cfg.paths("workspace.roots")
    t.add_row("Workspace sandbox", OK, ", ".join(str(p) for p in ws))

    voice = [("sounddevice", "audio I/O"), ("faster_whisper", "faster-whisper (STT)"), ("openwakeword", "openwakeword"),
             ("piper", "piper-tts"), ("kokoro_onnx", "kokoro-onnx")]
    for mod, label in voice:
        t.add_row(label, OK if _has(mod) else WARN, "requirements-voice.txt")
    custom = cfg.path("ears.wake.custom_model_path", "./models/ring.onnx")
    t.add_row("Wake model", OK if custom.exists() else WARN,
              f"custom {custom}" if custom.exists() else f"no custom 'ring' model; stock '{cfg.get('ears.wake.model')}' stands in")
    piper = cfg.path("tts.piper.model_path")
    t.add_row("Piper voice file", OK if piper.exists() else WARN, str(piper))
    if _has("sounddevice"):
        try:
            import sounddevice as sd

            devs = sd.query_devices()
            n_in = sum(1 for d in devs if d["max_input_channels"] > 0)
            t.add_row("Audio devices", OK if n_in else WARN, f"{n_in} input / {len(devs) - n_in} other")
        except Exception as exc:
            t.add_row("Audio devices", WARN, str(exc)[:80])
    console.print(t)
