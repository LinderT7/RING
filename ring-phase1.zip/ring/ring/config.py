"""Config loader: config.yaml + .env, with ${VAR:-default} expansion."""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent
_ENV_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")


def _expand(value: Any) -> Any:
    if isinstance(value, str):
        return _ENV_RE.sub(lambda m: os.environ.get(m.group(1)) or (m.group(2) or ""), value)
    if isinstance(value, dict):
        return {k: _expand(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expand(v) for v in value]
    return value


class Config:
    """Thin dotted-path accessor over the parsed YAML."""

    def __init__(self, data: dict, root: Path = PROJECT_ROOT):
        self.data = data
        self.root = Path(root)

    @classmethod
    def load(cls, path: str | os.PathLike | None = None, root: Path = PROJECT_ROOT) -> "Config":
        load_dotenv(root / ".env")
        cfg_path = Path(path or os.environ.get("RING_CONFIG") or root / "config.yaml")
        data = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
        return cls(_expand(data), root)

    def get(self, dotted: str, default: Any = None) -> Any:
        node: Any = self.data
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return default if node is None else node

    def set(self, dotted: str, value: Any) -> None:
        parts = dotted.split(".")
        node = self.data
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = value

    def _to_path(self, raw: Any) -> Path:
        p = Path(str(raw)).expanduser()
        return p if p.is_absolute() else self.root / p

    def path(self, dotted: str, default: str | None = None) -> Path:
        return self._to_path(self.get(dotted, default))

    def paths(self, dotted: str) -> list[Path]:
        return [self._to_path(p) for p in (self.get(dotted, []) or [])]
