"""Slash directives — handled locally, no LLM round-trip (they work offline)."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    from .orchestrator import Ring

HELP = (
    "Directive index:\n"
    "  /scan            local telemetry readout (no LLM)\n"
    "  /mode [m]        show or set gateway mode: local | cloud | auto\n"
    "  /usage           gateway usage this session\n"
    "  /tools           list armed constructs\n"
    "  /voice           force a voice scan (same as F2)\n"
    "  /mute, /unmute   silence or restore speech output\n"
    "  /clear           wipe conversation memory\n"
    "  /quit            power down"
)


async def _help(ring: "Ring", arg: str) -> str:
    return HELP


async def _scan(ring: "Ring", arg: str) -> str:
    import asyncio

    snap = await asyncio.to_thread(ring.telemetry.snapshot)
    ring.snapshot = snap
    return snap.readout(
        float(ring.cfg.get("telemetry.ring_charge_alert_pct", 20)),
        float(ring.cfg.get("telemetry.ram_alert_pct", 92)),
    )


async def _mode(ring: "Ring", arg: str) -> str:
    if not arg:
        return f"Gateway mode {ring.router.describe()}."
    try:
        ring.router.set_mode(arg.lower())
    except ValueError as exc:
        return f"Rejected. {exc}."
    return f"Gateway mode set: {ring.router.describe()}."


async def _usage(ring: "Ring", arg: str) -> str:
    u = ring.router.usage
    return (f"Gateway usage: {u.calls} calls, {u.prompt_tokens} tokens in, {u.completion_tokens} out, "
            f"${u.cost_usd:.4f}, {u.errors} backend faults. Last: {u.last_backend or 'none'} {u.last_model}.")


async def _tools(ring: "Ring", arg: str) -> str:
    def tag(t) -> str:
        if t.confirm is True:
            return "  [always authorizes]"
        return "  [authorizes unless pre-approved]" if callable(t.confirm) else ""

    rows = [f"  {t.name}{tag(t)}" for t in ring.registry.tools()]
    return f"{len(rows)} constructs armed:\n" + "\n".join(rows)


async def _voice(ring: "Ring", arg: str) -> str:
    ring.trigger_listen()
    return ""


async def _mute(ring: "Ring", arg: str) -> str:
    ring.tts.muted = True
    ring.tts.stop()
    return "Voice output muted."


async def _unmute(ring: "Ring", arg: str) -> str:
    ring.tts.muted = False
    return "Voice output restored."


async def _clear(ring: "Ring", arg: str) -> str:
    await ring.memory.clear()
    return "Conversation memory wiped."


async def _quit(ring: "Ring", arg: str) -> str:
    ring.request_quit()
    return ""


COMMANDS = {
    "help": _help, "?": _help, "scan": _scan, "mode": _mode, "usage": _usage, "tools": _tools,
    "voice": _voice, "mute": _mute, "unmute": _unmute, "clear": _clear, "quit": _quit, "exit": _quit,
}


async def dispatch(ring: "Ring", line: str) -> str:
    name, _, arg = line[1:].strip().partition(" ")
    fn = COMMANDS.get(name.lower())
    if fn is None:
        return f"Unknown directive '/{name}'. Issue /help for the directive index."
    return await fn(ring, arg.strip())
