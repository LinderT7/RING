"""Command-line entry point: wires config -> core -> HUD."""
from __future__ import annotations

import argparse
import asyncio
import logging
import sys

from .config import Config


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="ring", description="RING — Reconnaissance, Intelligence & Neural Gateway")
    p.add_argument("--config", help="path to config.yaml")
    p.add_argument("--hud", choices=["tui", "plain", "none"], help="interface (default from config; plain if not a TTY)")
    p.add_argument("--mode", choices=["local", "cloud", "auto"], help="gateway routing override")
    p.add_argument("--voice", action="store_true", help="enable wake word + STT + TTS")
    p.add_argument("--no-tts", action="store_true", help="with --voice: listen but don't speak")
    p.add_argument("--once", metavar="TEXT", help="run a single request headlessly, print the reply, exit")
    p.add_argument("--check", action="store_true", help="preflight scan of dependencies and services, then exit")
    return p.parse_args(argv)


def setup_logging(cfg: Config) -> None:
    log_dir = cfg.path("ring.data_dir", "./data")
    log_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        filename=str(log_dir / "ring.log"),
        level=getattr(logging, str(cfg.get("ring.log_level", "INFO")).upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )


async def amain(args: argparse.Namespace, cfg: Config) -> None:
    from .orchestrator import Ring

    voice = args.voice or bool(cfg.get("ears.voice_enabled", False))
    if voice:
        cfg.set("tts.enabled", not args.no_tts)  # TTS is built from config, so set it first
    ring = Ring(cfg)
    if voice:
        from .ears.voice import VoiceEars

        ring.ears = VoiceEars(cfg, ring.bus)

    if args.once:
        await ring.start(background=False)
        reply = await ring.handle(args.once, source="cli")
        print(reply)
        await ring.shutdown()
        return

    hud = args.hud or cfg.get("hud.mode", "tui")
    if hud == "tui" and not sys.stdout.isatty():
        hud = "plain"
    if hud == "tui":
        from .hud.dashboard import RingApp

        await RingApp(ring).run_async()
    elif hud == "plain":
        from .hud.plain import run_plain

        await run_plain(ring)
    else:
        await ring.run()


def main(argv=None) -> None:
    args = parse_args(argv)
    cfg = Config.load(args.config)
    if args.mode:
        cfg.set("llm.mode", args.mode)
    if args.check:
        from .diagnostics import run_preflight

        run_preflight(cfg)
        return
    setup_logging(cfg)
    try:
        asyncio.run(amain(args, cfg))
    except KeyboardInterrupt:
        pass
