"""Ears: wake word (openwakeword) + local speech-to-text (faster-whisper).

Half-duplex by design: the mic is only read while RING is in STANDBY/LISTENING,
so RING never hears its own voice. The orchestrator drives the cycle:
    wait_for_wake()  ->  capture_utterance()  ->  (text handed to the core)
"""
from __future__ import annotations

import asyncio
import logging

from ..config import Config
from ..events import EventBus

log = logging.getLogger("ring.ears")
FRAME = 1280  # 80 ms @ 16 kHz — openwakeword's native chunk


class VoiceEars:
    def __init__(self, cfg: Config, bus: EventBus):
        self.cfg, self.bus = cfg, bus
        self.ready = False
        self._q: asyncio.Queue | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._manual = asyncio.Event()
        self._gate = False           # audio callback only enqueues while True
        self._stream = None
        self._oww = None
        self._stt = None

    # ------------------------------------------------------------ lifecycle
    async def start(self, loop: asyncio.AbstractEventLoop) -> bool:
        self._loop = loop
        self._q = asyncio.Queue(maxsize=250)
        try:
            await asyncio.to_thread(self._load)
            self._open_stream()
        except Exception as exc:
            self.bus.emit("error", f"Voice stack offline: {type(exc).__name__}: {exc}. Typed input remains available.")
            log.exception("ears start failed")
            return False
        self.ready = True
        return True

    def _load(self) -> None:
        import sounddevice  # noqa: F401  (fail early if PortAudio is missing)
        import openwakeword
        from faster_whisper import WhisperModel
        from openwakeword.model import Model

        try:
            openwakeword.utils.download_models()  # no-op once cached
        except Exception:
            log.warning("openwakeword model download skipped", exc_info=True)
        custom = self.cfg.path("ears.wake.custom_model_path", "./models/ring.onnx")
        wake = str(custom) if custom.exists() else self.cfg.get("ears.wake.model", "hey_jarvis")
        self._oww = Model(wakeword_models=[wake], inference_framework="onnx")
        self._wake_name = "custom 'ring'" if custom.exists() else str(wake)
        self._stt = WhisperModel(
            self.cfg.get("ears.stt.model", "small.en"),
            device=self.cfg.get("ears.stt.device", "auto"),
            compute_type=self.cfg.get("ears.stt.compute_type", "int8"),
        )

    def _open_stream(self) -> None:
        import sounddevice as sd

        def callback(indata, frames, time_info, status):  # audio thread
            if self._gate:
                self._loop.call_soon_threadsafe(self._push, indata[:, 0].copy())

        self._stream = sd.InputStream(samplerate=16000, channels=1, dtype="int16", blocksize=FRAME, callback=callback)
        self._stream.start()

    def _push(self, frame) -> None:
        try:
            self._q.put_nowait(frame)
        except asyncio.QueueFull:
            pass

    async def stop(self) -> None:
        self._gate = False
        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None
        self.ready = False

    @property
    def wake_name(self) -> str:
        return getattr(self, "_wake_name", "n/a")

    def trigger(self) -> None:
        """Hotkey / manual scan request (skips the wake word)."""
        self._manual.set()

    def _flush(self) -> None:
        while self._q and not self._q.empty():
            self._q.get_nowait()

    # ---------------------------------------------------------------- wake
    async def wait_for_wake(self) -> str:
        threshold = float(self.cfg.get("ears.wake.threshold", 0.5))
        self._flush()
        self._gate = True
        try:
            while True:
                if self._manual.is_set():
                    self._manual.clear()
                    return "hotkey"
                try:
                    frame = await asyncio.wait_for(self._q.get(), 0.25)
                except asyncio.TimeoutError:
                    continue
                scores = self._oww.predict(frame)
                if scores and max(scores.values()) >= threshold:
                    if hasattr(self._oww, "reset"):
                        self._oww.reset()
                    return "wake word"
        finally:
            self._gate = False

    # ------------------------------------------------------------- capture
    async def capture_utterance(self) -> str:
        import numpy as np

        cap = self.cfg
        start_timeout = float(cap.get("ears.capture.start_timeout_s", 6))
        silence_s = float(cap.get("ears.capture.silence_ms", 900)) / 1000
        max_s = float(cap.get("ears.capture.max_seconds", 20))
        min_rms = float(cap.get("ears.capture.min_rms", 450))
        frame_s = FRAME / 16000

        self._flush()
        self._gate = True
        frames: list = []
        heard, quiet, elapsed = False, 0.0, 0.0
        try:
            while elapsed < max_s:
                try:
                    frame = await asyncio.wait_for(self._q.get(), 0.5)
                except asyncio.TimeoutError:
                    continue
                elapsed += frame_s
                rms = float(np.sqrt(np.mean(frame.astype(np.float32) ** 2)))
                if rms >= min_rms:
                    heard, quiet = True, 0.0
                elif heard:
                    quiet += frame_s
                if heard:
                    frames.append(frame)
                elif elapsed >= start_timeout:
                    return ""
                if heard and quiet >= silence_s:
                    break
        finally:
            self._gate = False
        if not frames:
            return ""
        audio = np.concatenate(frames).astype(np.float32) / 32768.0
        return await asyncio.to_thread(self._transcribe, audio)

    def _transcribe(self, audio) -> str:
        segments, _ = self._stt.transcribe(
            audio, language=self.cfg.get("ears.stt.language", "en"), vad_filter=True, beam_size=1
        )
        return " ".join(s.text.strip() for s in segments).strip()
