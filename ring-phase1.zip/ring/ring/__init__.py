"""RING — Reconnaissance, Intelligence & Neural Gateway."""

__version__ = "0.1.0"
