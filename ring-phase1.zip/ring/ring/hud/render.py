"""Rich renderables shared by the full-screen HUD and the plain console HUD."""
from __future__ import annotations

import time

from rich import box
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from ..events import Event
from ..state import HUD_LABELS, State

MODE_STYLE = {
    State.STANDBY: "bold green",
    State.LISTENING: "bold cyan",
    State.PROCESSING: "bold bright_cyan",
    State.EXECUTING: "bold yellow",
    State.SPEAKING: "bold magenta",
}
KIND_STYLE = {
    "user": ("OPERATOR", "cyan"),
    "ring": ("RING", "bold green"),
    "construct": ("CONSTRUCT", "yellow"),
    "system": ("SYSTEM", "dim white"),
    "alert": ("ALERT", "bold red"),
    "error": ("FAULT", "red"),
    "confirm": ("AUTHORIZE", "bold yellow"),
    "state": ("STATE", "dim"),
}


def level_style(pct: float, inverse: bool = False) -> str:
    if inverse:  # battery: low is bad
        return "red" if pct <= 20 else "yellow" if pct <= 50 else "green"
    return "red" if pct >= 90 else "yellow" if pct >= 70 else "green"


def bar(pct: float | None, width: int = 16, inverse: bool = False) -> Text:
    pct = max(0.0, min(100.0, pct or 0.0))
    filled = round(width * pct / 100)
    t = Text()
    t.append("█" * filled, style=level_style(pct, inverse))
    t.append("░" * (width - filled), style="grey35")
    return t


def format_event(ev: Event) -> Text:
    label, style = KIND_STYLE.get(ev.kind, (ev.kind.upper(), "white"))
    line = Text()
    line.append(time.strftime("%H:%M:%S ", time.localtime(ev.ts)), style="grey50")
    line.append(f"{label:<10}", style=style)
    line.append(ev.message, style=style if ev.kind in {"ring", "alert", "error", "confirm"} else "")
    return line


def render_mode(ring) -> Panel:
    state: State = ring.state.state
    body = Text()
    body.append(f"◉ {HUD_LABELS[state]}\n", style=MODE_STYLE[state])
    body.append(f"Gateway  {ring.router.describe()}\n", style="white")
    ears = "armed" if ring.ears is not None and ring.ears.ready else ("offline" if ring.ears is not None else "typed only")
    voice = "muted" if ring.tts.muted else ("online" if ring.tts.enabled else "text only")
    body.append(f"Ears     {ears}\nVoice    {voice}\nOan DB   offline (Phase 2)", style="grey70")
    return Panel(body, title="MODE", border_style=MODE_STYLE[state].replace("bold ", ""), box=box.ROUNDED)


def render_charge(snap) -> Panel:
    if snap is None:
        return Panel("Awaiting first scan…", title="RING CHARGE", border_style="green", box=box.ROUNDED)
    g = Table.grid(padding=(0, 1))
    g.add_column(width=7)
    g.add_column()
    g.add_column(justify="right")
    if snap.battery_percent is None:
        g.add_row("CHARGE", Text("▓" * 16, style="green"), "MAINS")
    else:
        mode = "⚡" if snap.plugged else "▼"
        g.add_row("CHARGE", bar(snap.battery_percent, inverse=True), f"{snap.battery_percent:.0f}% {mode}")
    g.add_row("CPU", bar(snap.cpu_percent), f"{snap.cpu_percent:.0f}%")
    g.add_row("RAM", bar(snap.ram_percent), f"{snap.ram_percent:.0f}%")
    g.add_row("DISK", bar(snap.disk_percent), f"{snap.disk_percent:.0f}%")
    for i, gpu in enumerate(snap.gpus[:2]):
        temp = f" {gpu['temp_c']}°C" if gpu.get("temp_c") is not None else ""
        g.add_row(f"GPU{i}", bar(gpu["util_percent"]), f"{gpu['util_percent']}%{temp}")
    if not snap.gpus:
        g.add_row("GPU", Text("no telemetry", style="grey50"), "")
    return Panel(g, title="RING CHARGE", border_style="green", box=box.ROUNDED)


def render_usage(router) -> Panel:
    u = router.usage
    t = Text()
    t.append(f"Calls    {u.calls}   Faults {u.errors}\n")
    t.append(f"Tokens   {u.prompt_tokens} in / {u.completion_tokens} out\n")
    t.append(f"Cost     ${u.cost_usd:.4f}\n")
    t.append(f"Last     {u.last_backend or '—'} {u.last_latency_s:.1f}s", style="grey70")
    return Panel(t, title="API USAGE", border_style="cyan", box=box.ROUNDED)
