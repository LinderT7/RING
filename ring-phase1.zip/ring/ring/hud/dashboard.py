"""Full-screen terminal HUD (Textual). One event loop shared with the RING core."""
from __future__ import annotations

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Input, RichLog, Static

from ..events import Event
from .render import format_event, render_charge, render_mode, render_usage

DEFAULT_PLACEHOLDER = "Query or /directive…   F2 voice scan · F3 mute · /help"


class RingApp(App):
    TITLE = "RING"
    CSS = """
    Screen { background: #03120a; }
    #title { height: 1; background: #0a3d1f; color: #9dffb8; text-style: bold; padding: 0 1; }
    #body { height: 1fr; }
    #side { width: 44; }
    #side Static { margin: 0 1 0 0; }
    #log { border: round #1f8a4c; background: #03120a; margin: 0 0 0 0; }
    #prompt { dock: bottom; border: tall #1f8a4c; }
    Footer { background: #0a3d1f; }
    """
    BINDINGS = [
        Binding("f2", "listen", "Voice scan"),
        Binding("f3", "mute", "Mute/unmute"),
        Binding("ctrl+l", "clear_log", "Clear log"),
        Binding("ctrl+q", "quit", "Quit"),
    ]

    def __init__(self, ring) -> None:
        super().__init__()
        self.ring = ring

    def compose(self) -> ComposeResult:
        yield Static(" ◉ RING  //  Reconnaissance, Intelligence & Neural Gateway", id="title")
        with Horizontal(id="body"):
            with Vertical(id="side"):
                yield Static(id="mode")
                yield Static(id="charge")
                yield Static(id="usage")
            yield RichLog(id="log", wrap=True, markup=False, highlight=False, max_lines=2000)
        yield Input(placeholder=DEFAULT_PLACEHOLDER, id="prompt")
        yield Footer()

    def on_mount(self) -> None:
        self.ring.bus.subscribe(self._on_event)
        self.set_interval(0.5, self._refresh_panels)
        self.run_worker(self.ring.run(), name="ring-core", group="ring")
        self.query_one("#prompt", Input).focus()
        self._refresh_panels()

    # ------------------------------------------------------------------ events
    def _on_event(self, ev: Event) -> None:
        if ev.kind == "quit":
            self.exit()
            return
        if ev.kind != "state":
            self.query_one("#log", RichLog).write(format_event(ev))
        if ev.kind == "confirm":
            self.query_one("#prompt", Input).placeholder = "AUTHORIZE construct?  y / n"
        self._refresh_panels()

    def _refresh_panels(self) -> None:
        self.query_one("#mode", Static).update(render_mode(self.ring))
        self.query_one("#charge", Static).update(render_charge(self.ring.snapshot))
        self.query_one("#usage", Static).update(render_usage(self.ring.router))
        if not self.ring.pending_confirm:
            self.query_one("#prompt", Input).placeholder = DEFAULT_PLACEHOLDER

    # ------------------------------------------------------------------- input
    def on_input_submitted(self, event: Input.Submitted) -> None:
        text = event.value
        event.input.value = ""
        self.ring.submit_text(text, source="text")

    def action_listen(self) -> None:
        self.ring.trigger_listen()

    def action_mute(self) -> None:
        self.ring.tts.muted = not self.ring.tts.muted
        if self.ring.tts.muted:
            self.ring.tts.stop()
        self.ring.bus.emit("system", "Voice output muted." if self.ring.tts.muted else "Voice output restored.")

    def action_clear_log(self) -> None:
        self.query_one("#log", RichLog).clear()

    async def on_unmount(self) -> None:
        await self.ring.shutdown()
