"""Plain console HUD: Rich-formatted status lines + a stdin prompt. Works over SSH / pipes."""
from __future__ import annotations

import asyncio
import sys
import threading

from rich.console import Console
from rich.panel import Panel

from ..events import Event
from .render import format_event, render_charge


async def run_plain(ring, console: Console | None = None) -> None:
    console = console or Console()
    loop = asyncio.get_running_loop()
    done = asyncio.Event()

    def on_event(ev: Event) -> None:
        if ev.kind == "quit":
            done.set()
        elif ev.kind != "state":
            console.print(format_event(ev))

    ring.bus.subscribe(on_event)
    console.print(Panel("[bold green]◉ RING[/]  Reconnaissance, Intelligence & Neural Gateway\n"
                        "[grey70]Type a query or /help. Ctrl+C to exit.[/]", border_style="green"))

    def reader() -> None:  # daemon thread: never blocks interpreter exit
        for line in sys.stdin:
            loop.call_soon_threadsafe(ring.submit_text, line)
        loop.call_soon_threadsafe(ring.request_quit)

    threading.Thread(target=reader, daemon=True, name="ring-stdin").start()
    core = asyncio.create_task(ring.run())
    try:
        await done.wait()
        await asyncio.wait_for(core, 5)
    except (asyncio.TimeoutError, asyncio.CancelledError):
        core.cancel()
    finally:
        console.print(render_charge(ring.snapshot))
        await ring.shutdown()
