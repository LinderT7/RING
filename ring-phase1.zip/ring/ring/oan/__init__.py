"""Oan Database — PHASE 2 (not implemented in the MVP).

Planned contract (see README, "Phase 2"):

    class OanDatabase:
        async def ingest(paths: list[Path]) -> IngestReport   # md / pdf / code -> chunks -> ChromaDB
        async def query(text: str, k: int = 5) -> list[Hit]   # semantic search with source + line refs

and two registered constructs:  oan_query(question, k)   oan_ingest(path)
"""
