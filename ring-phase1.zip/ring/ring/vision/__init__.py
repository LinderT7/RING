"""Screen / window vision — PHASE 2 (not implemented in the MVP).

Planned contract (see README, "Phase 2"):

    capture_screen(monitor: int = 1) -> PNG bytes          # mss
    analyze_screen(question: str) -> str                   # image -> vision-capable model via the router

registered as the constructs:  scan_screen(question)   capture_window(title)
"""
