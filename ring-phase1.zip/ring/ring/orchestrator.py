"""The core: orchestrator + state machine driver.

Flow of one request:
    STANDBY/LISTENING -> PROCESSING (LLM) -> EXECUTING_CONSTRUCT (tools, may loop
    back to PROCESSING) -> SPEAKING (TTS) -> STANDBY

Everything runs on one asyncio loop: input sources push into a queue, a single
consumer handles one request at a time (guarded by `_busy`), while the telemetry
monitor and the voice loop run as sibling tasks.
"""
from __future__ import annotations

import asyncio
import json
import logging
import platform
from datetime import datetime
from typing import Any

from . import commands
from .brain.memory import Memory
from .brain.router import LLMRouter, ToolCall
from .config import Config
from .events import EventBus
from .hands.files import sandbox_roots
from .hands.registry import ToolContext, ToolRegistry, default_registry
from .hands.telemetry import Snapshot, telemetry
from .persona import build_system_prompt
from .state import State, StateMachine
from .voice.tts import create_tts

log = logging.getLogger("ring.core")

AFFIRMATIVE = {"y", "yes", "yeah", "confirm", "confirmed", "authorize", "authorized", "affirmative", "proceed", "go"}


class Ring:
    def __init__(self, cfg: Config, *, router=None, memory=None, tts=None, ears=None, registry: ToolRegistry | None = None):
        self.cfg = cfg
        self.bus = EventBus()
        self.state = StateMachine(self.bus)
        self.router = router or LLMRouter(cfg)
        self.memory = memory or Memory(
            cfg.path("memory.db_path", "./data/ring.db"),
            int(cfg.get("memory.context_messages", 24)),
            bool(cfg.get("memory.persist_across_runs", True)),
        )
        self.registry = registry or default_registry
        self.tts = tts or create_tts(cfg, self.bus)
        self.ears = ears
        self.telemetry = telemetry
        self.ctx = ToolContext(config=cfg, ring=self)
        self.snapshot: Snapshot | None = None

        self._queue: asyncio.Queue = asyncio.Queue()
        self._busy = asyncio.Lock()
        self._confirm_future: asyncio.Future | None = None
        self._tasks: list[asyncio.Task] = []
        self._armed = {"charge": True, "ram": True}
        self._started = False
        self._closed = False
        self._loop: asyncio.AbstractEventLoop | None = None

    # ================================================================ lifecycle
    async def start(self, background: bool = True) -> None:
        if self._started:
            return
        self._started = True
        self._loop = asyncio.get_running_loop()
        self.cfg.path("ring.data_dir", "./data").mkdir(parents=True, exist_ok=True)
        await self.memory.init()
        self.registry.load_builtin()
        self.registry.load_plugins(self.cfg.path("ring.plugins_dir", "./plugins"))
        for err in self.registry.load_errors:
            self.bus.emit("error", err)
        await self.tts.load()
        self.snapshot = await asyncio.to_thread(self.telemetry.snapshot)
        self.bus.emit(
            "system",
            f"RING online. {len(self.registry)} constructs armed. Gateway {self.router.describe()}. "
            f"Oan Database offline (Phase 2).",
        )
        if background:
            self._tasks.append(asyncio.create_task(self._monitor_loop(), name="ring-monitor"))
            if self.ears is not None:
                self._tasks.append(asyncio.create_task(self._voice_loop(), name="ring-voice"))

    async def run(self) -> None:
        """Main consumer loop. Returns after request_quit()."""
        await self.start()
        try:
            while True:
                item = await self._queue.get()
                if item is None:
                    break
                text, source = item
                try:
                    await self.handle(text, source)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    log.exception("request failed")
                    self.bus.emit("error", f"Core fault: {type(exc).__name__}: {exc}")
                    self.state.reset("fault")
        finally:
            await self.shutdown()

    async def shutdown(self) -> None:
        if self._closed:
            return
        self._closed = True
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        self.tts.stop()
        if self.ears is not None:
            await self.ears.stop()
        self.memory.close()

    def request_quit(self) -> None:
        self.bus.emit("quit", "Ring powering down.")
        self._queue.put_nowait(None)

    # ================================================================ input
    @property
    def pending_confirm(self) -> bool:
        return self._confirm_future is not None and not self._confirm_future.done()

    def submit_text(self, text: str, source: str = "text") -> None:
        """Entry point for every input channel. Must be called on the loop thread."""
        text = text.strip()
        if not text:
            return
        if self.pending_confirm:  # answers a construct authorization prompt
            self._confirm_future.set_result(text.lower().rstrip(".!") in AFFIRMATIVE)
            return
        if self._busy.locked() and not text.startswith("/"):
            self.bus.emit("system", "Request queued behind active operation.")
        self._queue.put_nowait((text, source))

    def trigger_listen(self) -> None:
        if self.ears is not None and self.ears.ready:
            self.ears.trigger()
            self.bus.emit("system", "Manual scan engaged.")
        else:
            self.bus.emit("system", "Voice stack offline. Typed input remains available (see README, Voice setup).")

    # ================================================================ request handling
    async def handle(self, text: str, source: str = "text") -> str:
        text = text.strip()
        if not text:
            return ""
        if text.startswith("/"):
            reply = await commands.dispatch(self, text)
            if reply:
                self.bus.emit("ring", reply, source="directive")
            return reply or ""
        return await self._converse(text, source)

    async def _converse(self, text: str, source: str) -> str:
        async with self._busy:
            self.bus.emit("user", text, source=source)
            self.state.transition(State.PROCESSING, source)
            turn: list[dict] = [{"role": "user", "content": text}]
            final: str
            try:
                history = await self.memory.recent()
                messages = [{"role": "system", "content": self._system_prompt()}, *history, *turn]
                tools = self.registry.schemas()
                final = ""
                for _ in range(int(self.cfg.get("llm.max_tool_steps", 6))):
                    resp = await self.router.chat(messages, tools)
                    if not resp.tool_calls:
                        final = resp.text or "No output returned from the gateway."
                        break
                    assistant = {
                        "role": "assistant",
                        "content": resp.text or None,
                        "tool_calls": [
                            {"id": c.id, "type": "function",
                             "function": {"name": c.name, "arguments": json.dumps(c.arguments)}}
                            for c in resp.tool_calls
                        ],
                    }
                    messages.append(assistant)
                    turn.append(assistant)
                    self.state.transition(State.EXECUTING, ", ".join(c.name for c in resp.tool_calls))
                    for call in resp.tool_calls:
                        tool_msg = {"role": "tool", "tool_call_id": call.id, "name": call.name,
                                    "content": await self._execute_construct(call)}
                        messages.append(tool_msg)
                        turn.append(tool_msg)
                    self.state.transition(State.PROCESSING, "construct results")
                else:
                    final = "Construct loop limit reached. Request incomplete; narrow the objective."
                turn.append({"role": "assistant", "content": final})
                await self.memory.add_many(turn)
            except Exception as exc:
                log.exception("conversation failed")
                self.bus.emit("error", f"Gateway fault: {exc}")
                final = "Neural gateway fault. Request not completed."
            await self._deliver(final)
            return final

    async def _deliver(self, text: str) -> None:
        self.bus.emit("ring", text)
        if self.tts.enabled and not self.tts.muted:
            self.state.transition(State.SPEAKING, "deliver")
            try:
                await self.tts.speak(text)
            finally:
                self.state.reset("turn complete")
        else:
            self.state.reset("turn complete")

    # ================================================================ constructs
    async def _execute_construct(self, call: ToolCall) -> str:
        short = ", ".join(f"{k}={str(v)[:60]!r}" for k, v in call.arguments.items())
        self.bus.emit("construct", f"{call.name}({short})", name=call.name, args=call.arguments)
        if self.registry.get(call.name) is None:
            return json.dumps({"ok": False, "error": f"unknown construct '{call.name}'"})
        try:
            if self.registry.needs_confirmation(call.name, call.arguments, self.ctx):
                if not await self.confirm(f"Authorize construct {call.name}({short})?  [y/N]"):
                    self.bus.emit("construct", f"{call.name}: authorization denied")
                    return json.dumps({"ok": False, "error": "Operator denied authorization. Do not retry."})
            result = await asyncio.wait_for(
                self.registry.invoke(call.name, call.arguments, self.ctx),
                timeout=float(self.cfg.get("llm.tool_timeout_s", 120)),
            )
            payload: dict[str, Any] = {"ok": True, "result": result}
            self.bus.emit("construct", f"{call.name}: complete")
        except Exception as exc:
            payload = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
            self.bus.emit("construct", f"{call.name}: failed ({type(exc).__name__}: {str(exc)[:120]})")
        out = json.dumps(payload, default=str)
        limit = int(self.cfg.get("llm.max_tool_output_chars", 4000))
        return out if len(out) <= limit else out[:limit] + '..."[truncated]"'

    async def confirm(self, prompt: str) -> bool:
        """Ask the Operator to authorize a construct. Typed y/n (voice confirmation is Phase 2)."""
        fut = asyncio.get_running_loop().create_future()
        self._confirm_future = fut
        self.bus.emit("confirm", prompt)
        if self.tts.enabled:
            await self.tts.chime("alert")
        try:
            return await asyncio.wait_for(fut, float(self.cfg.get("shell.confirm_timeout_s", 45)))
        except asyncio.TimeoutError:
            self.bus.emit("system", "Authorization window expired. Construct aborted.")
            return False
        finally:
            self._confirm_future = None

    # ================================================================ prompt
    def _system_prompt(self) -> str:
        try:
            workspace = str(sandbox_roots(self.ctx)[0])
        except Exception:
            workspace = "unconfigured"
        return build_system_prompt(
            operator=self.cfg.get("ring.operator", "Operator"),
            workspace=workspace,
            oan_status="offline (Phase 2)",
            now=datetime.now().astimezone().strftime("%A %d %B %Y, %H:%M %Z"),
            host=f"{platform.system()} {platform.release()}",
            voice_mode=self.tts.enabled,
        )

    # ================================================================ background tasks
    async def _monitor_loop(self) -> None:
        interval = float(self.cfg.get("telemetry.poll_seconds", 2))
        while True:
            try:
                self.snapshot = await asyncio.to_thread(self.telemetry.snapshot)
                await self._check_alerts(self.snapshot)
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("monitor tick failed")
            await asyncio.sleep(interval)

    async def _check_alerts(self, s: Snapshot) -> None:
        thr = float(self.cfg.get("telemetry.ring_charge_alert_pct", 20))
        rearm = float(self.cfg.get("telemetry.ring_charge_rearm_pct", 25))
        if s.battery_percent is not None:
            if s.plugged is not True and s.battery_percent < thr and self._armed["charge"]:
                self._armed["charge"] = False
                await self.announce(f"Warning. Ring Charge at {s.battery_percent:.0f} percent. Recharge advised.")
            elif s.plugged is True or s.battery_percent >= rearm:
                self._armed["charge"] = True
        ram_thr = float(self.cfg.get("telemetry.ram_alert_pct", 92))
        if s.ram_percent >= ram_thr and self._armed["ram"]:
            self._armed["ram"] = False
            await self.announce(f"Warning. Memory pressure at {s.ram_percent:.0f} percent.")
        elif s.ram_percent < ram_thr - 7:
            self._armed["ram"] = True

    async def announce(self, text: str, level: str = "alert") -> None:
        """Proactive message: always logged, spoken only if RING is idle."""
        self.bus.emit(level, text)
        if self.tts.enabled and not self.tts.muted and not self._busy.locked():
            async with self._busy:
                if self.state.state is State.STANDBY:
                    self.state.transition(State.SPEAKING, "announce")
                    try:
                        await self.tts.chime("alert")
                        await self.tts.speak(text)
                    finally:
                        self.state.reset("announce complete")

    async def _voice_loop(self) -> None:
        if not await self.ears.start(asyncio.get_running_loop()):
            return
        self.bus.emit("system", f"Ears online. Wake channel armed ({self.ears.wake_name}). F2 forces a scan.")
        while True:
            while self._busy.locked() or self.state.state is not State.STANDBY:
                await asyncio.sleep(0.1)
            origin = await self.ears.wait_for_wake()
            if self._busy.locked() or self.state.state is not State.STANDBY:
                continue
            self.state.transition(State.LISTENING, origin)
            await self.tts.chime("wake")
            text = await self.ears.capture_utterance()
            if text:
                self._queue.put_nowait((text, "voice"))  # state stays LISTENING until the core picks it up
            else:
                self.bus.emit("system", "No signal detected. Standing by.")
                self.state.reset("no speech")
