"""Short-term conversation memory (SQLite). One rolling log, trimmed on read."""
from __future__ import annotations

import asyncio
import json
import sqlite3
import threading
import time
from pathlib import Path


class Memory:
    def __init__(self, path: str | Path, context_messages: int = 24, persist: bool = True):
        self.path = Path(path)
        self.limit = context_messages
        self.persist = persist
        self._conn: sqlite3.Connection | None = None
        self._lock = threading.Lock()

    async def init(self) -> None:
        await asyncio.to_thread(self._init)

    def _init(self) -> None:
        if self.path != Path(":memory:"):
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS messages(
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 ts REAL NOT NULL, role TEXT NOT NULL, content TEXT,
                 tool_calls TEXT, tool_call_id TEXT, name TEXT)"""
        )
        if not self.persist:
            self._conn.execute("DELETE FROM messages")
        self._conn.commit()

    # ------------------------------------------------------------------ write
    async def add_many(self, messages: list[dict]) -> None:
        """Persist a finished turn atomically, so history never holds a dangling tool call."""
        await asyncio.to_thread(self._add_many, messages)

    def _add_many(self, messages: list[dict]) -> None:
        rows = [
            (
                time.time(),
                m["role"],
                m.get("content"),
                json.dumps(m["tool_calls"]) if m.get("tool_calls") else None,
                m.get("tool_call_id"),
                m.get("name"),
            )
            for m in messages
        ]
        with self._lock, self._conn:  # type: ignore[union-attr]
            self._conn.executemany(  # type: ignore[union-attr]
                "INSERT INTO messages(ts, role, content, tool_calls, tool_call_id, name) VALUES (?,?,?,?,?,?)",
                rows,
            )

    async def clear(self) -> None:
        def _clear() -> None:
            with self._lock, self._conn:  # type: ignore[union-attr]
                self._conn.execute("DELETE FROM messages")  # type: ignore[union-attr]

        await asyncio.to_thread(_clear)

    # ------------------------------------------------------------------- read
    async def recent(self) -> list[dict]:
        return await asyncio.to_thread(self._recent)

    def _recent(self) -> list[dict]:
        with self._lock:
            cur = self._conn.execute(  # type: ignore[union-attr]
                "SELECT role, content, tool_calls, tool_call_id, name FROM messages ORDER BY id DESC LIMIT ?",
                (self.limit,),
            )
            rows = list(reversed(cur.fetchall()))
        out: list[dict] = []
        for role, content, tool_calls, tool_call_id, name in rows:
            m: dict = {"role": role, "content": content}
            if tool_calls:
                m["tool_calls"] = json.loads(tool_calls)
            if tool_call_id:
                m["tool_call_id"] = tool_call_id
            if name:
                m["name"] = name
            out.append(m)
        # The window may start mid-turn; a turn must begin with a user message.
        while out and out[0]["role"] != "user":
            out.pop(0)
        return out

    async def count(self) -> int:
        def _count() -> int:
            with self._lock:
                return self._conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0]  # type: ignore[union-attr]

        return await asyncio.to_thread(_count)

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None
