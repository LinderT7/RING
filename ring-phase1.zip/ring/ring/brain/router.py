"""Neural gateway: LLM router over LiteLLM (Ollama local + OpenRouter cloud)."""
from __future__ import annotations

import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from ..config import Config

log = logging.getLogger("ring.router")

MODES = ("local", "cloud", "auto")


class GatewayError(RuntimeError):
    pass


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class LLMResponse:
    text: str
    tool_calls: list[ToolCall]
    backend: str
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    latency_s: float = 0.0


@dataclass
class UsageTracker:
    """'API usage' for the HUD."""
    calls: int = 0
    errors: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    last_backend: str = ""
    last_model: str = ""
    last_latency_s: float = 0.0
    by_backend: dict[str, int] = field(default_factory=dict)

    def record(self, resp: LLMResponse, cost: float = 0.0) -> None:
        self.calls += 1
        self.prompt_tokens += resp.prompt_tokens
        self.completion_tokens += resp.completion_tokens
        self.cost_usd += cost
        self.last_backend, self.last_model, self.last_latency_s = resp.backend, resp.model, resp.latency_s
        self.by_backend[resp.backend] = self.by_backend.get(resp.backend, 0) + 1


@dataclass
class Backend:
    name: str
    model: str
    api_base: str | None
    api_key: str | None
    timeout_s: float


class LLMRouter:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.usage = UsageTracker()

    # ---------------------------------------------------------------- routing
    @property
    def mode(self) -> str:
        mode = str(self.cfg.get("llm.mode", "auto")).lower()
        return mode if mode in MODES else "auto"

    def set_mode(self, mode: str) -> None:
        if mode not in MODES:
            raise ValueError(f"mode must be one of {MODES}")
        self.cfg.set("llm.mode", mode)

    def backends(self) -> list[Backend]:
        c = self.cfg
        local = Backend(
            "local",
            c.get("llm.local.model", "ollama_chat/llama3.1:8b"),
            c.get("llm.local.api_base", "http://localhost:11434"),
            None,
            float(c.get("llm.local.timeout_s", 90)),
        )
        cloud = Backend(
            "cloud",
            c.get("llm.cloud.model", "openrouter/anthropic/claude-sonnet-4.5"),
            None,
            os.environ.get(c.get("llm.cloud.api_key_env", "OPENROUTER_API_KEY")),
            float(c.get("llm.cloud.timeout_s", 60)),
        )
        if self.mode == "local":
            return [local]
        if self.mode == "cloud":
            return [cloud]
        return [local, cloud] if c.get("llm.prefer", "local") == "local" else [cloud, local]

    def describe(self) -> str:
        names = " > ".join(b.name for b in self.backends())
        return f"{self.mode.upper()} ({names})"

    # ---------------------------------------------------------------- calls
    async def chat(self, messages: list[dict], tools: list[dict] | None = None) -> LLMResponse:
        errors: list[str] = []
        for backend in self.backends():
            try:
                return await self._call(backend, messages, tools)
            except Exception as exc:  # fall through to the backup ring
                self.usage.errors += 1
                errors.append(f"{backend.name}: {type(exc).__name__}: {str(exc)[:200]}")
                log.warning("backend %s failed: %s", backend.name, exc)
        raise GatewayError(" | ".join(errors) or "no backend configured")

    async def _call(self, b: Backend, messages: list[dict], tools: list[dict] | None) -> LLMResponse:
        if b.name == "cloud" and not b.api_key:
            raise GatewayError("OPENROUTER_API_KEY is not set")
        import litellm  # lazy: import is slow and optional for tests

        litellm.drop_params = True
        litellm.suppress_debug_info = True
        kwargs: dict[str, Any] = dict(
            model=b.model,
            messages=messages,
            temperature=float(self.cfg.get("llm.temperature", 0.2)),
            max_tokens=int(self.cfg.get("llm.max_tokens", 700)),
            timeout=b.timeout_s,
        )
        if b.api_base:
            kwargs["api_base"] = b.api_base
        if b.api_key:
            kwargs["api_key"] = b.api_key
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"

        t0 = time.monotonic()
        raw = await litellm.acompletion(**kwargs)
        latency = time.monotonic() - t0

        msg = raw.choices[0].message
        calls: list[ToolCall] = []
        for tc in getattr(msg, "tool_calls", None) or []:
            args = tc.function.arguments
            if isinstance(args, str):
                try:
                    args = json.loads(args) if args.strip() else {}
                except json.JSONDecodeError:
                    args = {}
            calls.append(ToolCall(tc.id or f"call_{uuid.uuid4().hex[:8]}", tc.function.name, args or {}))

        usage = getattr(raw, "usage", None)
        resp = LLMResponse(
            text=(getattr(msg, "content", None) or "").strip(),
            tool_calls=calls,
            backend=b.name,
            model=b.model,
            prompt_tokens=int(getattr(usage, "prompt_tokens", 0) or 0),
            completion_tokens=int(getattr(usage, "completion_tokens", 0) or 0),
            latency_s=latency,
        )
        try:
            cost = float(litellm.completion_cost(completion_response=raw) or 0.0)
        except Exception:
            cost = 0.0
        self.usage.record(resp, cost)
        return resp
