# RING — Reconnaissance, Intelligence & Neural Gateway

Local-first desktop AI assistant with a Power Ring persona. One asyncio loop runs
voice, HUD, LLM calls and tools without blocking each other.

```
STANDBY ─wake/hotkey─▶ LISTENING ─▶ PROCESSING ◀──▶ EXECUTING CONSTRUCT ─▶ SPEAKING ─▶ STANDBY
            (typed input enters at PROCESSING)       (tool loop)
```

| Ring concept            | Implementation                                                        |
|-------------------------|-----------------------------------------------------------------------|
| Ring Charge             | `hands/telemetry.py` — battery/CPU/RAM/disk/GPU + API usage; alerts < 20 % |
| Construct Generation    | `hands/registry.py` — `@register_tool` plugin registry                |
| Oan Database            | `oan/` — **Phase 2** (ChromaDB RAG)                                   |
| Primary / backup ring   | `brain/router.py` — Ollama local first, OpenRouter cloud on failure   |

## Directory structure

```
ring/
├── main.py                  launcher  (python main.py)
├── config.yaml              behaviour: routing, sandbox, voice, hardware, thresholds
├── .env.example             secrets + machine-specific values (copy to .env)
├── requirements.txt         core (text + HUD)        ├── requirements-voice.txt   wake word / STT / TTS
├── requirements-phase2.txt  chromadb, mss, pypdf     └── requirements-dev.txt     pytest
├── plugins/                 drop-in constructs (auto-loaded) — example_clock.py
├── tests/test_smoke.py      13 tests, no network/audio/LLM needed
├── models/                  (you create) wake-word + voice model files
├── data/                    (auto) ring.db memory, ring.log
└── ring/
    ├── cli.py               argument parsing, wiring, HUD selection
    ├── config.py            YAML + .env loader, ${VAR:-default} expansion
    ├── orchestrator.py      Ring: queue, request loop, tool loop, alerts, voice loop
    ├── state.py             State enum + transition table
    ├── events.py            EventBus (core -> HUD/loggers)
    ├── persona.py           system prompt
    ├── commands.py          /directives (work offline, no LLM)
    ├── diagnostics.py       --check preflight
    ├── brain/               router.py (LiteLLM, fallback, usage), memory.py (SQLite)
    ├── hands/               registry.py, telemetry.py, files.py, shell.py, hardware.py
    ├── ears/voice.py        openwakeword + faster-whisper
    ├── voice/               tts.py (piper/kokoro), audio.py (playback + chime)
    ├── hud/                 dashboard.py (Textual), plain.py (Rich console), render.py
    ├── oan/  vision/        Phase 2 stubs
```

## Run the MVP

```bash
cd ring
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # then edit (see below)
python main.py --check                                 # preflight: what's online / missing
python main.py                                         # full-screen HUD
```

**Brain — pick one or both:**
- *Local (primary ring):* install Ollama, then `ollama pull llama3.1:8b` (any model with tool
  support works; set `RING_LOCAL_MODEL`). Small models are weaker at multi-step tool use; if
  constructs misfire, try a larger or Qwen-class tool-capable model.
- *Cloud (backup ring):* set `OPENROUTER_API_KEY` in `.env`. Check
  `openrouter.ai/models` for the current slug and set `RING_CLOUD_MODEL`.
- `RING_LLM_MODE=auto` tries local first and falls back to cloud on any failure.
  Switch live with `/mode local|cloud|auto`.
  Privacy: in cloud mode, tool output (file contents, command output) is sent to the cloud model.

**Using it:** type a request, or a directive: `/scan` (instant telemetry, no LLM), `/mode`,
`/usage`, `/tools`, `/mute`, `/clear`, `/quit`. Other launch options:
`--hud plain` (SSH-friendly), `--once "scan telemetry"` (headless, prints reply), `--mode cloud`.

**Authorization:** overwriting a file, running any command outside the `shell.auto_allow` set,
`run_script`, and all hardware writes pause and ask `y/n` in the input box. No answer in 45 s = denied.
Confirmations are typed in the MVP (also true when using voice).

### Voice setup (after text mode works)

```bash
pip install -r requirements-voice.txt          # Linux first: sudo apt install libportaudio2
```
1. **TTS voice:** download a Piper voice into `models/piper/` (both `.onnx` and `.onnx.json`) from
   `huggingface.co/rhasspy/piper-voices` (default config expects `en_US-ryan-high`).
   Or switch to Kokoro: `tts.backend: kokoro` and place its two files per `config.yaml`.
2. **Wake word — read this:** openWakeWord ships **no pretrained "ring" model**. Until you train one,
   `config.yaml` uses the stock `hey_jarvis` model as a stand-in. To get "Ring": train a custom model with
   the openWakeWord training notebook (synthetic-speech training, no recordings needed) and save it as
   `models/ring.onnx` — it is picked up automatically. Train on **"hey ring"** if you can: one short syllable
   false-triggers far more than a two-word phrase.
3. Run `python main.py --voice` (add `--no-tts` to listen without speaking). `F2` forces a scan
   without the wake word; `F3` mutes. The mic is half-duplex: it is closed while RING speaks.
4. Noisy room? Raise `ears.capture.min_rms`. NVIDIA GPU? `ears.stt.device: cuda`, `compute_type: float16`.

## Add a construct

Drop a file in `plugins/` (see `plugins/example_clock.py`):

```python
from ring.hands.registry import register_tool, ToolContext

@register_tool(confirm=True)                     # confirm=True → always asks first
def pulse_led(ctx: ToolContext, pin: int, ms: int = 200) -> dict:
    """Pulse an LED on the connected board.

    Args:
        pin: GPIO pin number.
        ms: pulse length in milliseconds.
    """
    ...
```
The schema the model sees is generated from the type hints and docstring. `ctx` is injected and
hidden. `confirm` may also be a callable `(args, ctx) -> bool` for per-call decisions.
Hardware: set `hardware.enabled: true`, `SERIAL_PORT` / `MQTT_HOST` in `.env`, `pip install pyserial paho-mqtt`.

## Safety model

- File constructs are confined to `workspace.roots` (symlinks and `..` resolved before the check).
- The shell deny-list and auto-allow list are **speed bumps, not a sandbox**. The real control is
  the authorization prompt; keep `auto_allow` short. Commands run with your user's privileges.
- Tool output and file contents are labelled as data in the system prompt, but prompt injection via
  documents you ask RING to read is a real risk — another reason writes/commands require approval.

## Tests

```bash
pip install -r requirements-dev.txt && python -m pytest tests -q
```
Covers schema generation, sandbox escape attempts, shell policy, state transitions, memory windowing,
a full scripted turn incl. tool loop and authorization allow/deny, battery-alert hysteresis,
local→cloud fallback, LiteLLM response parsing, and a headless Textual run.
**Not covered by automated tests** (needs real hardware/models): microphone capture, wake word, Whisper,
Piper/Kokoro playback, live Ollama/OpenRouter calls, GPU telemetry on a real NVIDIA card.

---

## Phase 2 — Oan Database (RAG) + screen vision

Both plug into existing seams; no core changes needed beyond registering constructs.

### Oan Database (`ring/oan/`)

```bash
pip install -r requirements-phase2.txt
```
1. `oan/store.py`: `chromadb.PersistentClient(path=cfg.path("oan.persist_dir"))`,
   `get_or_create_collection("oan_archive")`. Chroma's default embedder (MiniLM, ONNX) is fully local.
2. `oan/ingest.py`: walk `oan.sources`; read `.md/.txt/.py/...` as text and `.pdf` via `pypdf`.
   Chunk ~800 chars with ~100 overlap (split code on `def`/`class` boundaries when you can). Upsert with
   `ids=f"{path}:{chunk_no}"`, `metadatas={"path", "chunk", "mtime"}`; skip files whose mtime is unchanged.
3. `oan/query.py`: `collection.query(query_texts=[q], n_results=k)` → return text + `path:chunk` citations.
4. Register constructs in `oan/__init__.py`:
   ```python
   @register_tool
   async def oan_query(ctx: ToolContext, question: str, k: int = 5) -> list: ...
   @register_tool(confirm=True)
   async def oan_ingest(ctx: ToolContext, path: str) -> dict: ...
   ```
   Import `ring.oan` from `BUILTIN_MODULES` in `hands/registry.py` when `oan.enabled`.
5. In `orchestrator._system_prompt` replace `oan_status="offline (Phase 2)"` with real doc/chunk counts,
   and add a persona line: *cite the source path for every Oan answer*.
6. Run ingestion in a background task (`asyncio.to_thread`) with HUD progress events; add a
   file-watcher (`watchfiles`) later for live re-indexing.

### Screen vision (`ring/vision/`)

1. `vision/capture.py`: `mss.mss().grab(monitor)` → `PIL.Image` → downscale to ≤ 1568 px → PNG bytes.
   Window capture: grab the window's bounding box (`pygetwindow` on Windows, `xdotool` on X11).
2. `vision/analyze.py`: send a message with an image part through the **existing router**:
   ```python
   {"role": "user", "content": [
       {"type": "text", "text": question},
       {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}}]}
   ```
   Local needs a vision model (`ollama pull llava` / `qwen2.5vl`); cloud uses any vision-capable slug.
   Add `llm.vision_model` to config and let `LLMRouter.chat(..., model_override=...)` select it.
3. Register `scan_screen(question)` and `capture_window(title)`. Gate cloud-vision behind
   `confirm=True` — screenshots routinely contain secrets.
4. HUD: show a thumbnail path in the log; set the HUD mode label to *SCANNING* during capture.

### Other natural next steps
Voice-based authorization (capture one utterance in `Ring.confirm`), global hotkey via `pynput`,
streaming LLM tokens into TTS sentence-by-sentence, barge-in (`tts.stop()` on wake), wake-word-gated
follow-up conversations, and an alert for GPU thermals next to the existing Ring Charge alert.
