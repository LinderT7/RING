"""Smoke tests: no network, no audio, no LLM — a scripted FakeRouter drives the real core."""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from typing import Literal

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ring.brain.memory import Memory
from ring.brain.router import LLMResponse, ToolCall
from ring.config import Config
from ring.events import EventBus
from ring.hands import files, shell
from ring.hands.registry import ToolContext, ToolRegistry, default_registry, register_tool
from ring.orchestrator import Ring
from ring.state import InvalidTransition, State, StateMachine


# ------------------------------------------------------------------ fixtures
def make_cfg(tmp_path: Path) -> Config:
    return Config(
        {
            "ring": {"data_dir": str(tmp_path / "data"), "plugins_dir": str(Path(__file__).parent.parent / "plugins")},
            "workspace": {"roots": [str(tmp_path / "ws")]},
            "shell": {"auto_allow": ["ls", "echo", "pwd"], "auto_allow_prefixes": ["git status"],
                      "timeout_s": 10, "confirm_timeout_s": 5},
            "memory": {"db_path": str(tmp_path / "data" / "ring.db")},
            "llm": {"max_tool_steps": 4},
            "tts": {"enabled": False},
        },
        root=tmp_path,
    )


class FakeRouter:
    """Scripted gateway: each chat() call pops the next response."""

    def __init__(self, script):
        self.script = list(script)
        self.calls: list[list[dict]] = []
        self.usage = type("U", (), {"calls": 0, "errors": 0, "prompt_tokens": 0, "completion_tokens": 0,
                                    "cost_usd": 0.0, "last_backend": "", "last_model": "", "last_latency_s": 0.0})()

    def describe(self): return "FAKE"

    async def chat(self, messages, tools=None):
        self.calls.append(list(messages))
        return self.script.pop(0)


def reply(text="", calls=()):
    return LLMResponse(text=text, tool_calls=[ToolCall(f"c{i}", n, a) for i, (n, a) in enumerate(calls)],
                       backend="fake", model="fake")


class FakeTTS:
    enabled, muted = True, False
    def __init__(self): self.spoken = []
    async def load(self): ...
    async def speak(self, t): self.spoken.append(t)
    async def chime(self, k="speak"): ...
    def stop(self): ...


# --------------------------------------------------------------------- tests
def test_schema_from_signature_and_docstring():
    reg = ToolRegistry()

    @register_tool(registry=reg)
    def demo(ctx: ToolContext, target: str, mode: Literal["a", "b"] = "a", n: int = 3, tag: "Undefined" = "x") -> dict:  # noqa: F821
        """Do a thing.

        Args:
            target: what to act on.
            n: how many.
        """

    t = reg.get("demo")
    props = t.parameters["properties"]
    assert "ctx" not in props and t.parameters["required"] == ["target"]
    assert props["mode"] == {"type": "string", "enum": ["a", "b"], "default": "a"}
    # an unresolvable annotation ("Undefined") must not erase the other hints
    assert props["n"] == {"type": "integer", "description": "how many.", "default": 3}
    assert t.description == "Do a thing."
    assert t.bind({"target": "x", "n": "7", "bogus": 1}) == {"target": "x", "n": 7}  # coercion + unknown args dropped
    with pytest.raises(Exception, match="missing required"):
        t.bind({"n": 1})


def test_state_machine_rejects_illegal_jump():
    sm = StateMachine(EventBus())
    sm.transition(State.PROCESSING)
    sm.transition(State.EXECUTING)
    with pytest.raises(InvalidTransition):
        sm.transition(State.LISTENING)
    sm.reset()
    assert sm.state is State.STANDBY


def test_builtin_and_plugin_constructs_load(tmp_path):
    default_registry.load_builtin()
    loaded = default_registry.load_plugins(Path(__file__).parent.parent / "plugins")
    names = default_registry.names()
    for expected in ("scan_telemetry", "ring_charge", "run_command", "read_file", "write_file", "serial_send", "current_time"):
        assert expected in names
    assert "example_clock" in loaded


def test_file_sandbox(tmp_path):
    ctx = ToolContext(make_cfg(tmp_path))
    with pytest.raises(PermissionError):
        files.resolve_safe(ctx, "../outside.txt")
    with pytest.raises(PermissionError):
        files.resolve_safe(ctx, "/etc/passwd")

    async def go():
        default_registry.load_builtin()
        await default_registry.invoke("write_file", {"path": "notes/a.md", "content": "hello"}, ctx)
        got = await default_registry.invoke("read_file", {"path": "notes/a.md"}, ctx)
        assert got["content"] == "hello"
        hits = await default_registry.invoke("search_files", {"pattern": "*.md", "query": "HELL"}, ctx)
        assert hits["results"][0]["line"] == 1
        # overwriting an existing file requires authorization; a fresh path does not
        assert default_registry.needs_confirmation("write_file", {"path": "notes/a.md", "content": "x"}, ctx)
        assert not default_registry.needs_confirmation("write_file", {"path": "notes/b.md", "content": "x"}, ctx)

    asyncio.run(go())


def test_shell_policy(tmp_path):
    cfg = make_cfg(tmp_path)
    assert shell.denied_reason("rm -rf /") and shell.denied_reason("sudo ls")
    assert shell.is_auto_allowed("ls -la", cfg)
    assert shell.is_auto_allowed("git status", cfg)
    assert not shell.is_auto_allowed("ls; rm x", cfg)        # shell operators
    assert not shell.is_auto_allowed("ls /etc", cfg)         # path outside workspace
    assert not shell.is_auto_allowed("python evil.py", cfg)  # not on the list

    async def go():
        ctx = ToolContext(cfg)
        default_registry.load_builtin()
        out = await default_registry.invoke("run_command", {"command": "echo ring-online"}, ctx)
        assert "ring-online" in out["output"] and out["exit_code"] == 0
        with pytest.raises(PermissionError):
            await default_registry.invoke("run_command", {"command": "rm -rf /"}, ctx)

    asyncio.run(go())


def test_memory_window_starts_on_user_turn(tmp_path):
    async def go():
        m = Memory(tmp_path / "m.db", context_messages=3)
        await m.init()
        await m.add_many([
            {"role": "user", "content": "q1"},
            {"role": "assistant", "content": None, "tool_calls": [{"id": "c", "type": "function", "function": {"name": "x", "arguments": "{}"}}]},
            {"role": "tool", "tool_call_id": "c", "name": "x", "content": "{}"},
            {"role": "assistant", "content": "a1"},
        ])
        recent = await m.recent()  # window of 3 begins at the orphaned tool message -> trimmed to nothing valid
        assert recent == [] or recent[0]["role"] == "user"
        await m.add_many([{"role": "user", "content": "q2"}, {"role": "assistant", "content": "a2"}])
        assert [x["content"] for x in await m.recent()] == ["q2", "a2"]
        m.close()

    asyncio.run(go())


def test_full_turn_with_construct(tmp_path):
    async def go():
        cfg = make_cfg(tmp_path)
        router = FakeRouter([reply(calls=[("scan_telemetry", {"detail": "summary"})]), reply("Scan complete. Nominal.")])
        tts = FakeTTS()
        ring = Ring(cfg, router=router, tts=tts)
        await ring.start(background=False)
        states = []
        ring.bus.subscribe(lambda e: states.append(e.data["new"]) if e.kind == "state" else None)

        out = await ring.handle("status report")
        assert out == "Scan complete. Nominal."
        assert states == ["PROCESSING", "EXECUTING_CONSTRUCT", "PROCESSING", "SPEAKING", "STANDBY"]
        assert tts.spoken == ["Scan complete. Nominal."]
        # tool result reached the model on the 2nd call, and the whole turn was persisted
        tool_msgs = [m for m in router.calls[1] if m["role"] == "tool"]
        assert json.loads(tool_msgs[0]["content"])["ok"] is True
        assert await ring.memory.count() == 4
        # persona is in the system prompt
        assert "RING" in router.calls[0][0]["content"]
        await ring.shutdown()

    asyncio.run(go())


def test_authorization_flow(tmp_path):
    async def go():
        cfg = make_cfg(tmp_path)
        ws = Path(cfg.get("workspace.roots")[0])
        ws.mkdir(parents=True)
        (ws / "keep.txt").write_text("original")
        script = [
            reply(calls=[("write_file", {"path": "keep.txt", "content": "clobbered"})]),
            reply("Authorization denied. Standing down."),
        ]
        ring = Ring(cfg, router=FakeRouter(script), tts=FakeTTS())
        await ring.start(background=False)
        ring.bus.subscribe(lambda e: ring.submit_text("n") if e.kind == "confirm" else None)  # operator says no
        await ring.handle("overwrite keep.txt")
        assert (ws / "keep.txt").read_text() == "original"

        ring2 = Ring(make_cfg(tmp_path), router=FakeRouter([
            reply(calls=[("write_file", {"path": "keep.txt", "content": "updated"})]), reply("Done.")]), tts=FakeTTS())
        await ring2.start(background=False)
        ring2.bus.subscribe(lambda e: ring2.submit_text("yes") if e.kind == "confirm" else None)  # operator says yes
        await ring2.handle("overwrite keep.txt")
        assert (ws / "keep.txt").read_text() == "updated"
        await ring.shutdown(); await ring2.shutdown()

    asyncio.run(go())


def test_gateway_failure_resets_to_standby(tmp_path):
    class Boom(FakeRouter):
        async def chat(self, *a, **k): raise RuntimeError("ollama down")

    async def go():
        ring = Ring(make_cfg(tmp_path), router=Boom([]), tts=FakeTTS())
        await ring.start(background=False)
        out = await ring.handle("hello")
        assert "fault" in out.lower() and ring.state.state is State.STANDBY
        await ring.shutdown()

    asyncio.run(go())


def test_battery_alert_fires_once_and_rearms(tmp_path):
    from ring.hands.telemetry import Snapshot

    def snap(pct, plugged=False):
        return Snapshot(ts=0, cpu_percent=1, cpu_count=1, ram_percent=10, ram_used_gb=1, ram_total_gb=8,
                        disk_percent=1, disk_free_gb=1, battery_percent=pct, plugged=plugged, battery_secs_left=None)

    async def go():
        ring = Ring(make_cfg(tmp_path), router=FakeRouter([]), tts=FakeTTS())
        alerts = []
        ring.bus.subscribe(lambda e: alerts.append(e.message) if e.kind == "alert" else None)
        await ring._check_alerts(snap(30))
        await ring._check_alerts(snap(19))
        await ring._check_alerts(snap(18))   # no repeat
        assert len(alerts) == 1 and "19 percent" in alerts[0]
        await ring._check_alerts(snap(40))   # re-arm
        await ring._check_alerts(snap(15))
        assert len(alerts) == 2
        await ring._check_alerts(snap(10, plugged=True))  # plugged in: silent
        assert len(alerts) == 2

    asyncio.run(go())


def test_tui_headless_roundtrip(tmp_path):
    pytest.importorskip("textual")
    from textual.widgets import Input, RichLog

    from ring.hud.dashboard import RingApp

    async def go():
        ring = Ring(make_cfg(tmp_path), router=FakeRouter([reply("Link established. Systems nominal.")]), tts=FakeTTS())
        app = RingApp(ring)
        async with app.run_test(size=(140, 40)) as pilot:
            await pilot.pause(0.3)
            app.query_one("#prompt", Input).value = "ping"
            await pilot.press("enter")
            await pilot.pause(0.6)
            text = "\n".join(strip.text for strip in app.query_one("#log", RichLog).lines)
            assert "ping" in text and "Link established" in text and "RING online" in text
            app.query_one("#prompt", Input).value = "/scan"
            await pilot.press("enter")
            await pilot.pause(0.6)
            text = "\n".join(strip.text for strip in app.query_one("#log", RichLog).lines)
            assert "Scanning local telemetry" in text

    asyncio.run(go())


def test_router_parses_litellm_tool_calls(tmp_path, monkeypatch):
    """Exercises the real LLMRouter._call parsing with a stubbed litellm.acompletion (no network)."""
    litellm = pytest.importorskip("litellm")
    from ring.brain.router import LLMRouter

    seen = {}

    async def fake_acompletion(**kw):
        seen.update(kw)
        return litellm.ModelResponse(
            choices=[{"message": {"role": "assistant", "content": None, "tool_calls": [
                {"id": "call_1", "type": "function",
                 "function": {"name": "read_file", "arguments": json.dumps({"path": "a.md"})}}]}}],
            usage={"prompt_tokens": 11, "completion_tokens": 7, "total_tokens": 18},
        )

    monkeypatch.setattr(litellm, "acompletion", fake_acompletion)
    cfg = make_cfg(tmp_path)
    cfg.set("llm.mode", "local")
    router = LLMRouter(cfg)

    async def go():
        resp = await router.chat([{"role": "user", "content": "x"}], default_registry.schemas())
        assert resp.tool_calls[0].name == "read_file" and resp.tool_calls[0].arguments == {"path": "a.md"}
        assert resp.prompt_tokens == 11 and router.usage.calls == 1
        assert seen["tool_choice"] == "auto" and seen["api_base"].startswith("http")

    default_registry.load_builtin()
    asyncio.run(go())


def test_auto_mode_falls_back_to_cloud(tmp_path, monkeypatch):
    litellm = pytest.importorskip("litellm")
    from ring.brain.router import LLMRouter

    async def flaky(**kw):
        if kw["model"].startswith("ollama"):
            raise ConnectionError("ollama down")
        return litellm.ModelResponse(choices=[{"message": {"role": "assistant", "content": "Backup ring engaged."}}],
                                     usage={"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2})

    monkeypatch.setattr(litellm, "acompletion", flaky)
    monkeypatch.setenv("OPENROUTER_API_KEY", "test-key")
    router = LLMRouter(make_cfg(tmp_path))  # default mode: auto, prefer local

    async def go():
        resp = await router.chat([{"role": "user", "content": "x"}])
        assert resp.backend == "cloud" and resp.text == "Backup ring engaged."
        assert router.usage.errors == 1

    asyncio.run(go())
